import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { RecordFormModal } from '@/src/components/RecordFormModal';
import { MODULE_MAP } from '@/src/core/moduleRegistry';
import { useAppData } from '@/src/data/AppDataProvider';
import { AttendanceScreen } from '@/src/attendance/AttendanceScreen';
import { EmployeeDirectoryScreen } from '@/src/employees/EmployeeDirectoryScreen';
import { ImportControlCenterScreen } from '@/src/imports/ImportControlCenterScreen';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
import { DATA_MODE } from '@/src/services/apiClient';
const REMOTE_CREATABLE_MODULES=new Set(['office-tasks','customers','products','service-tickets','expenses','supplier-claims','notifications']);

export default function ModuleScreen(){
  const {key}=useLocalSearchParams<{key:string}>();
  const moduleKey=String(key);
  if(moduleKey==='attendance-location')return <AttendanceScreen/>;
  if(moduleKey==='employee-directory')return <EmployeeDirectoryScreen mode="directory"/>;
  if(moduleKey==='employee-verification')return <EmployeeDirectoryScreen mode="verification"/>;
  if(moduleKey==='employee-id-cards')return <EmployeeDirectoryScreen mode="id_cards"/>;
  if(moduleKey==='import-control-center')return <ImportControlCenterScreen/>;
  return <GenericModuleScreen moduleKey={moduleKey}/>;
}

function GenericModuleScreen({moduleKey}:{moduleKey:string}){
  const router=useRouter();
  const module=MODULE_MAP[moduleKey];
  const {currentUser,getRecords,addRecord,deleteRecord}=useAppData();
  const [open,setOpen]=useState(false);
  const records=useMemo(()=>module?getRecords(module.key):[],[module,getRecords]);
  const formModule=useMemo(()=>{
    if(!module||currentUser?.role!=='customer'||module.key!=='service-tickets')return module;
    const allowed=new Set(['machine','model','serialNumber','warrantyStatus','issueCategory','problemDescription','priority']);
    return {...module,fields:module.fields.filter(field=>allowed.has(field.key)),statusOptions:['pending','open']};
  },[module,currentUser?.role]);
  if(!module)return <Screen><Text>Module not found.</Text></Screen>;
  const canAccess=Boolean(currentUser&&module.roles.includes(currentUser.role));
  const canCreate=Boolean(currentUser&&canAccess&&module.fields.length>0&&module.createRoles.includes(currentUser.role)&&(DATA_MODE==='local'||REMOTE_CREATABLE_MODULES.has(module.key)));
  if(!canAccess)return <Screen><Stack.Screen options={{headerShown:false}}/><View style={styles.header}><Pressable onPress={()=>router.back()} style={styles.back}><Ionicons name="arrow-back" size={22} color={colors.primary}/></Pressable><View style={styles.heading}><Text style={styles.title}>Access denied</Text><Text style={styles.sub}>{module.permission}</Text></View></View><Card style={styles.empty}><Ionicons name="lock-closed-outline" size={38} color={colors.mutedForeground}/><Text style={styles.emptyTitle}>You do not have permission for {module.title}</Text><Text style={styles.emptyText}>This module is restricted by role-based access control.</Text></Card></Screen>;
  return <Screen><Stack.Screen options={{headerShown:false}}/>
    <View style={styles.header}><Pressable onPress={()=>router.back()} style={styles.back}><Ionicons name="arrow-back" size={22} color={colors.primary}/></Pressable><View style={styles.heading}><Text style={styles.title}>{module.title}</Text><Text style={styles.sub}>{module.subtitle}</Text></View>{canCreate?<Pressable onPress={()=>setOpen(true)} style={styles.add}><Ionicons name="add" size={24} color={colors.primaryForeground}/></Pressable>:null}</View>
    <Text style={styles.routeMeta}>{module.routeName} • {module.apiEndpoint}</Text>
    <View style={styles.summary}><Text style={styles.summaryValue}>{records.length}</Text><Text style={styles.summaryLabel}>Total records</Text></View>
    {records.length===0?<Card style={styles.empty}><Ionicons name={module.icon} size={38} color={colors.mutedForeground}/><Text style={styles.emptyTitle}>No records yet</Text><Text style={styles.emptyText}>{canCreate?'Add the first verified record for this module.':'No records are available for this account yet.'}</Text>{canCreate?<Pressable onPress={()=>setOpen(true)} style={styles.emptyButton}><Text style={styles.emptyButtonText}>Add First Record</Text></Pressable>:null}</Card>:records.map(record=><Card key={record.id} style={styles.record}><View style={styles.recordTop}><View style={{flex:1}}><Text style={styles.recordTitle}>{record.title}</Text><Text style={styles.ref}>{record.reference||record.id}</Text></View><View style={styles.status}><Text style={styles.statusText}>{record.status.replaceAll('_',' ')}</Text></View></View><View style={styles.recordBottom}><Text style={styles.date}>{record.date}</Text>{record.amount!==undefined?<Text style={styles.amount}>৳{record.amount.toLocaleString()}</Text>:null}{DATA_MODE==='local'?<Pressable onPress={()=>Alert.alert('Delete record','This action cannot be undone.',[{text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>deleteRecord(module.key,record.id)}])}><Ionicons name="trash-outline" size={18} color={colors.destructive}/></Pressable>:null}</View></Card>)}
    {formModule?<RecordFormModal visible={open} module={formModule} onClose={()=>setOpen(false)} onSave={values=>addRecord(module.key,values)}/>:null}
  </Screen>;
}
const styles=StyleSheet.create({header:{minHeight:68,flexDirection:'row',alignItems:'center',gap:spacing.md},back:{width:40,height:40,borderRadius:radius.md,backgroundColor:colors.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:colors.border},heading:{flex:1},title:{fontFamily:typography.bold,fontSize:19,color:colors.text},sub:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,marginTop:2},routeMeta:{fontFamily:typography.regular,fontSize:9,color:colors.mutedForeground,marginTop:-4,marginBottom:spacing.sm},add:{width:42,height:42,borderRadius:radius.md,backgroundColor:colors.primary,alignItems:'center',justifyContent:'center'},summary:{backgroundColor:colors.primary,borderRadius:radius.lg,padding:spacing.lg,marginTop:spacing.sm,marginBottom:spacing.lg},summaryValue:{fontFamily:typography.bold,fontSize:28,color:colors.primaryForeground},summaryLabel:{fontFamily:typography.medium,fontSize:11,color:colors.orangeLight,marginTop:2},empty:{alignItems:'center',paddingVertical:40},emptyTitle:{fontFamily:typography.semibold,fontSize:16,color:colors.text,marginTop:spacing.md,textAlign:'center'},emptyText:{fontFamily:typography.regular,fontSize:11,lineHeight:17,color:colors.mutedForeground,textAlign:'center',marginTop:spacing.sm,maxWidth:280},emptyButton:{marginTop:spacing.lg,borderRadius:radius.md,backgroundColor:colors.orangeLight,paddingHorizontal:spacing.lg,paddingVertical:12},emptyButtonText:{fontFamily:typography.semibold,fontSize:12,color:colors.secondary},record:{marginBottom:spacing.md},recordTop:{flexDirection:'row',alignItems:'flex-start',gap:spacing.sm},recordTitle:{fontFamily:typography.semibold,fontSize:14,color:colors.text},ref:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,marginTop:3},status:{backgroundColor:colors.navyLight,borderRadius:radius.pill,paddingHorizontal:9,paddingVertical:5},statusText:{fontFamily:typography.semibold,fontSize:9,color:colors.primary,textTransform:'capitalize'},recordBottom:{marginTop:spacing.md,paddingTop:spacing.sm,borderTopWidth:1,borderTopColor:colors.border,flexDirection:'row',alignItems:'center',gap:spacing.md},date:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,flex:1},amount:{fontFamily:typography.bold,fontSize:12,color:colors.secondary}});
