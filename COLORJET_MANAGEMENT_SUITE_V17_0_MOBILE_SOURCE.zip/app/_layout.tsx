/** UI LOCKED FILE */
import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import { AppDataProvider } from '@/src/data/AppDataProvider';
import { colors } from '@/src/theme/tokens';
SplashScreen.preventAutoHideAsync().catch(()=>undefined);
export default function RootLayout(){const [loaded]=useFonts({Inter_400Regular,Inter_500Medium,Inter_600SemiBold,Inter_700Bold});useEffect(()=>{if(loaded)SplashScreen.hideAsync().catch(()=>undefined)},[loaded]);if(!loaded)return null;return <SafeAreaProvider><AppDataProvider><StatusBar style="light" backgroundColor={colors.primary}/><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:colors.background}}}/></AppDataProvider></SafeAreaProvider>}
