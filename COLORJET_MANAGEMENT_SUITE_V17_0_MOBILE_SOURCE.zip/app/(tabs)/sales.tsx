/** UI LOCKED FILE */
import React from 'react';import { ModuleOverview } from '@/src/components/ModuleOverview';export default function Sales(){return <ModuleOverview title="Sales" subtitle="Customers, invoices and collections" groups={['Sales','Accounts']}/>}
