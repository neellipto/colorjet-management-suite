/** UI LOCKED FILE */
import React from 'react';import { ModuleOverview } from '@/src/components/ModuleOverview';export default function Inventory(){return <ModuleOverview title="Inventory" subtitle="Products, stock, parts and receiving" groups={['Inventory']}/>}
