/** UI LOCKED FILE */
import React from 'react';import { ModuleOverview } from '@/src/components/ModuleOverview';export default function Service(){return <ModuleOverview title="Service" subtitle="Tickets, engineer jobs and warranty" groups={['Service']}/>}
