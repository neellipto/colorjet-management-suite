/** UI LOCKED FILE */
import React, { useMemo, useState } from 'react';
import { StyleSheet, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { AppHeader } from '@/src/components/ui/AppHeader';
import { ModuleCard } from '@/src/components/ui/ModuleCard';
import { SectionHeader } from '@/src/components/ui/SectionHeader';
import { getVisibleModules, moduleGroups } from '@/src/core/moduleRegistry';
import { useAppData } from '@/src/data/AppDataProvider';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
export default function More(){const router=useRouter();const {currentUser,getRecords}=useAppData();const [query,setQuery]=useState('');const modules=useMemo(()=>currentUser?getVisibleModules(currentUser.role).filter(m=>`${m.title} ${m.subtitle}`.toLowerCase().includes(query.toLowerCase())):[],[currentUser,query]);return <Screen><AppHeader title="More" subtitle="All business modules" onProfile={()=>router.push('/profile')}/><TextInput value={query} onChangeText={setQuery} placeholder="Search modules" placeholderTextColor={colors.mutedForeground} style={styles.search}/>{moduleGroups.map(group=>{const groupModules=modules.filter(m=>m.group===group);if(!groupModules.length)return null;return <View key={group}><SectionHeader title={group}/><View style={styles.grid}>{groupModules.map(module=><ModuleCard key={module.key} module={module} count={getRecords(module.key).length} onPress={()=>router.push({pathname:'/module/[key]',params:{key:module.key}})}/>)}</View></View>})}</Screen>}
const styles=StyleSheet.create({search:{height:48,borderRadius:radius.md,borderWidth:1,borderColor:colors.border,backgroundColor:colors.card,paddingHorizontal:spacing.lg,fontFamily:typography.regular,color:colors.text,marginTop:spacing.sm},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',gap:spacing.md}});
