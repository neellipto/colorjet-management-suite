import React from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { Redirect } from 'expo-router';
import { useAppData } from '@/src/data/AppDataProvider';
import { colors } from '@/src/theme/tokens';
export default function Index(){const {ready,ownerExists,currentUser}=useAppData();if(!ready)return <View style={styles.loading}><ActivityIndicator size="large" color={colors.primary}/></View>;if(!ownerExists)return <Redirect href="/setup"/>;if(!currentUser)return <Redirect href="/login"/>;return <Redirect href="/(tabs)"/>}
const styles=StyleSheet.create({loading:{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:colors.background}});
