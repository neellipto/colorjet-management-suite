# COLORJET Management Suite V17.0 — Restart Baseline Status

**Release date:** 14 July 2026  
**Baseline:** `COLORJET_MANAGEMENT_SUITE_V16_FIXED_DELIVERY (1).zip`  
**Mobile version:** 1.7.0  
**Android package:** `com.colorjetbd.managementsuite`  
**Android versionCode:** 1700

## গুরুত্বপূর্ণ baseline finding

V16 delivery-এর source code এবং ভিতরের installable Android file একই version ছিল না। Source V16 হলেও included signed APK ছিল V15 baseline। তাই পুরোনো APK-কে V17 নামে rename/relabel করা হয়নি। এই release-এ সত্যিকারের V17 mobile source, cPanel integration patch, Android Hermes export validation এবং Web export validation দেওয়া হয়েছে।

## V17-এ সম্পন্ন কাজ

### 1. Production login ও role routing
- Device-local single Owner login বাদ দিয়ে cPanel API token login যুক্ত করা হয়েছে।
- Login, token refresh, logout, session restore এবং secure token storage যুক্ত হয়েছে।
- OWNER, ADMIN, MANAGER, ACCOUNTS, SALES, SERVICE_MANAGER, ENGINEER, STORE, OFFICE_STAFF এবং CUSTOMER role mapping রাখা হয়েছে।
- Role অনুযায়ী dashboard, module visibility এবং create permission আলাদা করা হয়েছে।

### 2. Customer User ও Customer Dashboard
- ERP user-এর সাথে নির্দিষ্ট `customer_id` link করার ব্যবস্থা যোগ হয়েছে।
- Customer নিজের dashboard, invoice, outstanding due, ledger, agreement, machine/warranty এবং service ticket দেখতে পারবে।
- Customer নিজের service ticket create করতে পারবে।
- Customer অন্য customer-এর record, staff attendance, admin notification বা internal data দেখতে পারবে না।

### 3. Attendance ও management KPI
- GPS-based check-in/check-out backend sync করা হয়েছে।
- Same-day duplicate action protection রাখা হয়েছে।
- Management dashboard-এ Today Attendance %, total staff, present, absent, late এবং checked-out summary backend থেকে আসে।
- CUSTOMER role-এর জন্য attendance action বন্ধ।

### 4. Notifications
- Existing notification feed mobile app-এ যুক্ত হয়েছে।
- OWNER/ADMIN controlled broadcast endpoint যোগ হয়েছে।
- Recipient targeting: all users, selected roles, employees, customers বা departments।
- Customer notification access নিজের account scope অনুযায়ী সীমাবদ্ধ।

### 5. Corporate A4 print standard
সব ERP print/report page-এ shared corporate header/footer ও A4 print stylesheet যোগ হয়েছে।

**Company profile:**
- COLORJET Bangladesh
- Quality • Commitment • Service
- Importer • Distributor • Solution Provider
- Industrial Digital Printing Technology
- www.colorjetbd.com
- Hotline: +8809677610610
- WhatsApp: +8801954100710
- Email: info@colorjet.com.bd
- Huda Centre, 44 Purana Paltan, Dhaka-1000, Bangladesh

Original uploaded branding logo path-ই ব্যবহার করা হয়েছে; logo redesign, recolor বা recreate করা হয়নি। Social URLs settings-এ valid link না দেওয়া পর্যন্ত print footer-এ social link দেখাবে না—কোনো link invent করা হয়নি।

### 6. Migration Manager
নতুন migration এখন ERP-এর **System Migration Manager** থেকে run করা যায়:

`20260714_v1700_customer_portal_mobile.sql`

এটি additive migration; existing business transaction delete বা overwrite করে না।

### 7. Existing bug fix
Supplier claim create flow-তে `claim_type` assignment bug ঠিক করা হয়েছে।

## Validation result

- PHP syntax lint: **312/312 passed**
- UI lock verification: **16 protected files passed**
- Module registry: **39 unique modules / 39 explicit API endpoints passed**
- TypeScript: **passed**
- ESLint: **passed**
- Attendance rule tests: **5/5 passed**
- Android Expo/Hermes export: **passed**
- Web static export: **passed; 16 routes generated**

## বর্তমান limitation

এই execution environment-এ Android SDK, Gradle toolchain এবং production signing keystore ছিল না। তাই এখানে নতুন signed APK/AAB তৈরি করা সম্ভব হয়নি। V17 source ও Android Hermes bundle compile validation pass করেছে; signed APK/AAB EAS Build বা configured Android build machine-এ তৈরি করতে হবে। পুরোনো V15 APK-কে V17 হিসেবে দেওয়া হয়নি।
