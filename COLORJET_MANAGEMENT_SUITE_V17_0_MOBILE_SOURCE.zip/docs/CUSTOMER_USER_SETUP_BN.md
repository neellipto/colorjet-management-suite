# Customer User ও Customer Portal Setup

## Customer account prerequisites

Customer user create করার আগে ERP Customers module-এ customer master record থাকতে হবে। Minimum:

- Customer name
- Mobile number
- Address
- Active status

## User creation

1. OWNER/ADMIN login করুন।
2. **Users & Permissions → Add User** যান।
3. Name দিন।
4. Email অথবা accepted login identifier দিন।
5. Role: `CUSTOMER`
6. Linked Customer: সংশ্লিষ্ট customer নির্বাচন করুন।
7. Temporary password দিন; public document বা message-এ password লিখবেন না।
8. Active = Yes
9. Save করুন।

## Customer কী দেখতে পারবে

- নিজের dashboard summary
- নিজের invoices
- নিজের outstanding due
- নিজের customer ledger
- নিজের machine/warranty information
- নিজের agreements
- নিজের service tickets
- নিজের জন্য applicable notifications

## Customer কী করতে পারবে

- Login/logout
- নিজের portal refresh
- নিজের service ticket create
- নিজের account-related records view
- configured Hotline/WhatsApp support action ব্যবহার

## Customer কী দেখতে বা করতে পারবে না

- অন্য customer-এর invoice, ledger, machine বা agreement
- Owner/Admin dashboard
- Employee attendance
- Internal staff messages/data
- Stock, supplier, cash-bank বা management reports
- User administration
- Global notification broadcast

## Data isolation check

দুটি আলাদা test customer এবং দুটি CUSTOMER user তৈরি করুন।

1. Customer A দিয়ে login করে invoice/ledger list দেখুন।
2. Logout করুন।
3. Customer B দিয়ে login করুন।
4. Customer A-এর কোনো record Customer B account-এ দেখা যাচ্ছে কি না পরীক্ষা করুন।
5. Direct API request-এও linked `customer_id` ছাড়া অন্য customer data return করা উচিত নয়।

## Common issue

### Customer dashboard empty
- User-এর Linked Customer blank কি না দেখুন।
- Linked customer-এর invoice/service/agreement data আছে কি না দেখুন।
- Migration completed কি না দেখুন।
- Mobile API base URL ঠিক আছে কি না দেখুন।

### Login হয় কিন্তু wrong dashboard
- User role database-এ `CUSTOMER` কি না দেখুন।
- App logout করে আবার login করুন যাতে নতুন token/session claim load হয়।

### 401 Unauthorized
- API base URL `/api/v1` পর্যন্ত সঠিক কি না দেখুন।
- HTTPS certificate valid কি না দেখুন।
- User active কি না দেখুন।
- Password reset করে পুনরায় login করুন।
