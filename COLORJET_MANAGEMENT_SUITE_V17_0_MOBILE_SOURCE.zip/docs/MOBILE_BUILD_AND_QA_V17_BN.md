# COLORJET Management Suite V17.0 — Mobile Build & QA Guide

## Source configuration

`mobile-source/.env.example` copy করে local `.env` তৈরি করুন:

```env
EXPO_PUBLIC_DATA_MODE=remote
EXPO_PUBLIC_API_BASE_URL=https://YOUR-ERP-DOMAIN/api/v1
```

API key, database password, cPanel password বা signing credential source control-এ রাখবেন না।

## Install dependencies

```bash
npm ci
```

## Mandatory validation

```bash
npm run verify
npx eslint app src scripts --no-cache
node --experimental-strip-types scripts/test-attendance-rules.mjs
```

Expected:

- UI lock pass
- No legacy host
- 39 modules / 39 explicit endpoints
- TypeScript pass
- ESLint pass
- Attendance tests 5/5

## Local Expo test

```bash
npx expo start
```

Physical Android device-এ Expo Go/dev build দিয়ে login, role routing, GPS permission, attendance, customer dashboard ও notification test করুন।

## APK build with EAS

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

`preview` profile APK generate করবে।

## AAB production build

```bash
eas build --platform android --profile production
```

Production profile Android App Bundle (AAB) generate করবে। Existing production signing credential ব্যবহার করতে হবে, যাতে package update হিসেবে install/publish হয়। Package অপরিবর্তিত:

```text
com.colorjetbd.managementsuite
```

## Build version

- App version: `1.7.0`
- Android versionCode: `1700`

Play Console-এ আগে 1700 বা বেশি versionCode ব্যবহার হয়ে থাকলে build-এর আগে versionCode বাড়াতে হবে।

## Release QA checklist

### Authentication
- Valid staff login
- Invalid password rejection
- CUSTOMER login
- Logout/token invalidation
- Session restore

### Role access
- Owner full dashboard
- Admin permissions
- Engineer operational modules
- Customer only own portal
- CUSTOMER cannot open attendance/admin modules

### Attendance
- Location permission required
- Check-in success
- Duplicate check-in blocked
- Check-out success
- Attendance % summary refresh

### Customer portal
- Own invoices only
- Own ledger only
- Own machine/warranty only
- Own agreements only
- Service ticket create
- Cross-customer data isolation

### Notifications
- Feed loads
- Role/customer targeting
- Customer cannot broadcast
- Owner/Admin broadcast authorization

### Print/report
- A4 header/footer
- Original logo
- Company profile correct
- Page content not hidden by fixed print header/footer
- Save as PDF output

## Current build evidence

এই package-এর source থেকে Android Hermes export এবং Web static export সফল হয়েছে। Android SDK/signing keystore ছাড়া local signed APK/AAB output তৈরি করা হয়নি।
