import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const API_BASE_URL = (process.env.EXPO_PUBLIC_API_BASE_URL ?? '').replace(/\/+$/, '');
const SESSION_KEY = 'colorjet_erp_api_session_v17';

export const DATA_MODE = process.env.EXPO_PUBLIC_DATA_MODE === 'remote' ? 'remote' : 'local';

export interface RemoteApiUser {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  employee_id?: string;
  department?: string;
  customer_id?: number | null;
  avatar?: string | null;
  must_change_password?: boolean;
}

export interface RemoteApiSession {
  access_token: string;
  refresh_token: string;
  access_expires_at?: string;
  refresh_expires_at?: string;
  user: RemoteApiUser;
}

type ApiEnvelope<T> = {
  ok?: boolean;
  success?: boolean;
  data?: T;
  message?: string;
  error?: { message?: string; code?: string };
  request_id?: string;
} & T;

export type ApiFailure = Error & { status?: number; code?: string; requestId?: string };

export function getApiBaseUrl(): string {
  return API_BASE_URL;
}

export function isRemoteConfigured(): boolean {
  return DATA_MODE === 'remote' && /^https:\/\//i.test(API_BASE_URL);
}

async function setRemoteSession(session: RemoteApiSession): Promise<void> {
  const value = JSON.stringify(session);
  if (Platform.OS === 'web') { await AsyncStorage.setItem(SESSION_KEY, value); return; }
  await SecureStore.setItemAsync(SESSION_KEY, value, {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  });
}

export async function getRemoteSession(): Promise<RemoteApiSession | null> {
  const raw = Platform.OS === 'web' ? await AsyncStorage.getItem(SESSION_KEY) : await SecureStore.getItemAsync(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as RemoteApiSession;
  } catch {
    await clearRemoteSession();
    return null;
  }
}

export async function clearRemoteSession(): Promise<void> {
  if (Platform.OS === 'web') { await AsyncStorage.removeItem(SESSION_KEY); return; }
  await SecureStore.deleteItemAsync(SESSION_KEY);
}

function createApiError(message: string, status?: number, code?: string, requestId?: string): ApiFailure {
  const error = new Error(message) as ApiFailure;
  error.status = status;
  error.code = code;
  error.requestId = requestId;
  return error;
}

function normalizePath(path: string): string {
  return path.replace(/^\/+/, '').replace(/^api\//, '');
}

async function parseResponse<T>(response: Response): Promise<ApiEnvelope<T>> {
  const text = await response.text();
  if (!text) return {} as ApiEnvelope<T>;
  try {
    return JSON.parse(text) as ApiEnvelope<T>;
  } catch {
    throw createApiError('ERP returned an invalid JSON response.', response.status, 'INVALID_JSON');
  }
}

async function rawRequest<T>(path: string, init: RequestInit, requireAuth: boolean, retried = false): Promise<T> {
  if (!isRemoteConfigured()) {
    throw createApiError('Remote ERP API is not configured. Set EXPO_PUBLIC_DATA_MODE=remote and a valid HTTPS API URL.', undefined, 'API_NOT_CONFIGURED');
  }

  const session = await getRemoteSession();
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (init.body && !(init.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  if (requireAuth && session?.access_token) headers.Authorization = `Bearer ${session.access_token}`;

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}/${normalizePath(path)}`, {
      ...init,
      headers: { ...headers, ...(init.headers ?? {}) },
    });
  } catch {
    throw createApiError('Unable to reach COLORJET ERP. Check internet or server availability.', undefined, 'NETWORK_ERROR');
  }

  const payload = await parseResponse<T>(response);
  if ((response.status === 401 || response.status === 403) && requireAuth && !retried && session?.refresh_token) {
    try {
      await refreshRemoteSession();
      return rawRequest<T>(path, init, requireAuth, true);
    } catch {
      await clearRemoteSession();
    }
  }

  if (!response.ok || payload.ok === false || payload.success === false) {
    throw createApiError(
      payload.error?.message || payload.message || `ERP request failed (${response.status}).`,
      response.status,
      payload.error?.code,
      payload.request_id,
    );
  }
  return (payload.data ?? payload) as T;
}

export async function remoteLogin(identifier: string, password: string): Promise<RemoteApiSession> {
  const session = await rawRequest<RemoteApiSession>('auth/login', {
    method: 'POST',
    body: JSON.stringify({
      identifier: identifier.trim(),
      password,
      device: {
        device_id: `${Platform.OS}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
        device_name: Platform.OS === 'web' ? 'COLORJET Web/PWA' : 'COLORJET Android',
        platform: Platform.OS,
        app_version: '1.7.0',
      },
    }),
  }, false);
  if (!session.access_token || !session.refresh_token || !session.user) {
    throw createApiError('ERP login did not return a valid session.', undefined, 'INVALID_LOGIN_RESPONSE');
  }
  await setRemoteSession(session);
  return session;
}

export async function refreshRemoteSession(): Promise<RemoteApiSession> {
  const current = await getRemoteSession();
  if (!current?.refresh_token) throw createApiError('Session expired. Sign in again.', 401, 'SESSION_EXPIRED');
  const update = await rawRequest<Partial<RemoteApiSession>>('auth/refresh', {
    method: 'POST',
    body: JSON.stringify({ refresh_token: current.refresh_token }),
  }, false, true);
  const next = { ...current, ...update, user: update.user ?? current.user } as RemoteApiSession;
  await setRemoteSession(next);
  return next;
}

export async function remoteLogout(): Promise<void> {
  try {
    await rawRequest('auth/logout', { method: 'POST' }, true);
  } finally {
    await clearRemoteSession();
  }
}

export async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  return rawRequest<T>(path, init, true);
}

export async function apiGet<T>(path: string): Promise<T> {
  return apiRequest<T>(path, { method: 'GET' });
}

export async function apiPost<T>(path: string, body: unknown, idempotencyKey?: string): Promise<T> {
  return apiRequest<T>(path, {
    method: 'POST',
    headers: idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : undefined,
    body: JSON.stringify(body),
  });
}

export function toSnakeCasePayload(values: Record<string, string | number>): Record<string, string | number> {
  return Object.fromEntries(Object.entries(values).map(([key, value]) => [key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`), value]));
}
