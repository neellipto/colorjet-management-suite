import type { ComponentProps } from 'react';
import type { Ionicons } from '@expo/vector-icons';

export type UserRole = 'owner' | 'admin' | 'manager' | 'accounts' | 'sales' | 'marketing' | 'engineer' | 'service_control' | 'store' | 'office_staff' | 'customer';
export type ModuleGroup = 'Core' | 'Sales' | 'Inventory' | 'Service' | 'Accounts' | 'Import' | 'HR' | 'Admin';
export type FieldType = 'text' | 'number' | 'date' | 'time' | 'status' | 'notes' | 'select' | 'phone' | 'email' | 'currency' | 'file';
export type IconName = ComponentProps<typeof Ionicons>['name'];

export interface AppUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  roleTitle: string;
  employeeCode: string;
  department: string;
  customerId?: number | null;
  mustChangePassword?: boolean;
  isActive: boolean;
}

export interface ModuleField {
  key: string;
  label: string;
  type: FieldType;
  required?: boolean;
  placeholder?: string;
  options?: string[];
}

export interface ModuleDefinition {
  key: string;
  title: string;
  subtitle: string;
  group: ModuleGroup;
  icon: IconName;
  roles: UserRole[];
  createRoles: UserRole[];
  statusOptions: string[];
  fields: ModuleField[];
  formId: string;
  routeName: string;
  screenComponent: string;
  apiEndpoint: string;
  mutationKey: string;
  permission: string;
  auditAction: string;
}

export interface ModuleRecord {
  id: string;
  moduleKey: string;
  title: string;
  reference: string;
  status: string;
  amount?: number;
  date?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  values: Record<string, string | number>;
  apiEndpoint?: string;
  mutationKey?: string;
  auditAction?: string;
}

export interface ActivityLogEntry {
  id: string;
  action: string;
  moduleKey: string;
  recordId: string;
  actorId: string;
  actorName: string;
  createdAt: string;
  details: string;
}

export interface UserNotification {
  id: string;
  title: string;
  body: string;
  moduleKey: string;
  recordId: string;
  status: 'unread' | 'read' | 'failed';
  priority: 'normal' | 'important' | 'urgent';
  createdAt: string;
  readAt?: string;
}

export type AttendanceAction = 'check_in' | 'check_out';
export type AttendanceSyncStatus = 'local_only' | 'pending' | 'synced';

export interface AttendanceLocation {
  latitude: number;
  longitude: number;
  accuracyM: number | null;
  altitudeM: number | null;
  heading: number | null;
  speedMps: number | null;
  capturedAt: string;
  mocked: boolean;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  attendanceDate: string;
  checkInAt: string;
  checkInLocation: AttendanceLocation;
  checkOutAt?: string;
  checkOutLocation?: AttendanceLocation;
  status: 'checked_in' | 'checked_out';
  checkInIdempotencyKey: string;
  checkOutIdempotencyKey?: string;
  syncStatus: AttendanceSyncStatus;
  createdAt: string;
  updatedAt: string;
}

export interface PersistedState {
  schemaVersion: number;
  company: {
    name: string;
    tagline: string;
    hotline: string;
    whatsapp: string;
    email: string;
    website: string;
  };
  records: Record<string, ModuleRecord[]>;
  attendance: AttendanceRecord[];
  auditLog: ActivityLogEntry[];
  notifications: UserNotification[];
  migratedAt: string;
}


export interface CustomerPortalDashboard {
  customer: {
    id: number;
    name: string;
    company_name?: string | null;
    phone?: string | null;
    email?: string | null;
    address?: string | null;
    city?: string | null;
    balance?: number | string;
  };
  summary: {
    total_invoices: number;
    total_sales: number;
    total_paid: number;
    total_due: number;
    overdue_due: number;
    total_tickets: number;
    open_tickets: number;
    completed_tickets: number;
    total_machines: number;
    warranty_active: number;
    total_agreements: number;
    agreement_remaining: number;
  };
  recent_invoices: Record<string, unknown>[];
  recent_tickets: Record<string, unknown>[];
}
