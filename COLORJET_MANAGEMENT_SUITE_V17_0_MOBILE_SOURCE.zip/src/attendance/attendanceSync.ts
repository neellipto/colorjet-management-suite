import { apiPost, DATA_MODE } from '@/src/services/apiClient';
import type { AttendanceAction, AttendanceRecord } from '@/src/types/domain';

export async function syncAttendancePunch(record: AttendanceRecord, action: AttendanceAction): Promise<boolean> {
  if (DATA_MODE !== 'remote') return false;
  const idempotencyKey = action === 'check_in' ? record.checkInIdempotencyKey : record.checkOutIdempotencyKey;
  if (!idempotencyKey) return false;
  const location = action === 'check_in' ? record.checkInLocation : record.checkOutLocation;
  if (!location) return false;
  await apiPost('/operations/attendance/check', {
    mode: action === 'check_in' ? 'in' : 'out',
    latitude: location.latitude,
    longitude: location.longitude,
    accuracy_m: location.accuracyM,
    altitude_m: location.altitudeM,
    is_mock: location.mocked ? 1 : 0,
    permission_level: 'foreground',
    captured_at: location.capturedAt,
  }, idempotencyKey);
  return true;
}
