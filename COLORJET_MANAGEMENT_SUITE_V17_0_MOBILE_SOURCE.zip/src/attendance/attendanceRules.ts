import type { AttendanceAction, AttendanceRecord } from '../types/domain';

export function assertAttendancePunchAllowed(existing: AttendanceRecord | undefined, action: AttendanceAction): void {
  if (action === 'check_in' && existing?.checkInAt) {
    throw new Error('Today’s check-in already exists. Duplicate attendance is not allowed.');
  }
  if (action === 'check_out' && !existing?.checkInAt) {
    throw new Error('Check-in is required before check-out.');
  }
  if (action === 'check_out' && existing?.checkOutAt) {
    throw new Error('Today’s check-out already exists. Duplicate attendance is not allowed.');
  }
}
