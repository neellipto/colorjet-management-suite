import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Stack, useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { useAppData } from '@/src/data/AppDataProvider';
import { captureAttendanceLocation, getLocationPermissionState } from './locationService';
import { formatAttendanceTime, localDateKey } from './attendanceUtils';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
import type { AttendanceAction } from '@/src/types/domain';

export function AttendanceScreen(){
  const router=useRouter();
  const {currentUser,state,punchAttendance}=useAppData();
  const [busy,setBusy]=useState<AttendanceAction|null>(null);
  const [permission,setPermission]=useState<'granted'|'denied'|'undetermined'>('undetermined');
  const todayKey=localDateKey();
  const today=useMemo(()=>state?.attendance.find(item=>item.employeeId===currentUser?.id&&item.attendanceDate===todayKey),[state?.attendance,currentUser?.id,todayKey]);
  const recent=useMemo(()=>state?.attendance.filter(item=>item.employeeId===currentUser?.id).slice().sort((a,b)=>b.attendanceDate.localeCompare(a.attendanceDate)).slice(0,10)??[],[state?.attendance,currentUser?.id]);

  useEffect(()=>{getLocationPermissionState().then(setPermission).catch(()=>setPermission('undetermined'));},[]);

  const punch=useCallback(async(action:AttendanceAction)=>{
    if(busy)return;
    setBusy(action);
    try{
      const location=await captureAttendanceLocation();
      setPermission('granted');
      const record=await punchAttendance(action,location);
      Alert.alert(action==='check_in'?'Check-in completed':'Check-out completed',`${record.employeeName}\n${action==='check_in'?formatAttendanceTime(record.checkInAt):formatAttendanceTime(record.checkOutAt)}\nGPS accuracy: ${location.accuracyM===null?'Unknown':`${Math.round(location.accuracyM)} m`}`);
    }catch(error){
      const message=error instanceof Error?error.message:'Attendance could not be recorded.';
      Alert.alert('Attendance not submitted',message,[{text:'Cancel',style:'cancel'},{text:'Open Settings',onPress:()=>Linking.openSettings().catch(()=>undefined)}]);
      if(message.toLowerCase().includes('permission'))setPermission('denied');
    }finally{setBusy(null);}
  },[busy,punchAttendance]);

  const canCheckIn=!today?.checkInAt;
  const canCheckOut=Boolean(today?.checkInAt&&!today?.checkOutAt);
  return <Screen>
    <Stack.Screen options={{headerShown:false}}/>
    <View style={styles.header}><Pressable onPress={()=>router.back()} style={styles.back}><Ionicons name="arrow-back" size={22} color={colors.primary}/></Pressable><View style={styles.heading}><Text style={styles.title}>Attendance</Text><Text style={styles.sub}>Location-verified check-in and check-out</Text></View></View>
    <Card style={styles.notice}><View style={styles.noticeIcon}><Ionicons name="location" size={22} color={permission==='granted'?colors.success:colors.warning}/></View><View style={{flex:1}}><Text style={styles.noticeTitle}>Location permission is mandatory</Text><Text style={styles.noticeText}>Every punch captures a fresh GPS position. Duplicate check-in/check-out is automatically blocked.</Text></View></Card>
    <View style={styles.statusCard}><Text style={styles.date}>{new Date().toLocaleDateString([], {weekday:'long',day:'2-digit',month:'long',year:'numeric'})}</Text><Text style={styles.status}>{today?.status==='checked_out'?'Completed':today?.status==='checked_in'?'Checked In':'Not Checked In'}</Text><View style={styles.timeGrid}><View style={styles.timeBox}><Text style={styles.timeLabel}>CHECK IN</Text><Text style={styles.timeValue}>{formatAttendanceTime(today?.checkInAt)}</Text></View><View style={styles.timeBox}><Text style={styles.timeLabel}>CHECK OUT</Text><Text style={styles.timeValue}>{formatAttendanceTime(today?.checkOutAt)}</Text></View></View></View>
    <Pressable disabled={!canCheckIn||Boolean(busy)} onPress={()=>punch('check_in')} style={[styles.action,styles.checkIn,(!canCheckIn||busy)&&styles.disabled]}><Ionicons name="log-in-outline" size={22} color={colors.primaryForeground}/><View style={{flex:1}}><Text style={styles.actionTitle}>{busy==='check_in'?'Capturing GPS…':'Check In with Location'}</Text><Text style={styles.actionSub}>Fresh precise location required</Text></View></Pressable>
    <Pressable disabled={!canCheckOut||Boolean(busy)} onPress={()=>punch('check_out')} style={[styles.action,styles.checkOut,(!canCheckOut||busy)&&styles.disabled]}><Ionicons name="log-out-outline" size={22} color={colors.primaryForeground}/><View style={{flex:1}}><Text style={styles.actionTitle}>{busy==='check_out'?'Capturing GPS…':'Check Out with Location'}</Text><Text style={styles.actionSub}>Available only after today’s check-in</Text></View></Pressable>
    <Text style={styles.section}>Recent Attendance</Text>
    {recent.length===0?<Card><Text style={styles.empty}>No attendance has been recorded yet.</Text></Card>:recent.map(item=><Card key={item.id} style={styles.record}><View style={styles.recordTop}><Text style={styles.recordDate}>{item.attendanceDate}</Text><Text style={[styles.badge,item.status==='checked_out'&&styles.badgeDone]}>{item.status==='checked_out'?'Completed':'Checked In'}</Text></View><View style={styles.recordTimes}><Text style={styles.recordText}>In: {formatAttendanceTime(item.checkInAt)}</Text><Text style={styles.recordText}>Out: {formatAttendanceTime(item.checkOutAt)}</Text></View><Text style={styles.gps}>GPS: {item.checkInLocation.latitude.toFixed(5)}, {item.checkInLocation.longitude.toFixed(5)} • {item.checkInLocation.accuracyM===null?'accuracy unavailable':`${Math.round(item.checkInLocation.accuracyM)} m`}</Text></Card>)}
  </Screen>;
}
const styles=StyleSheet.create({header:{minHeight:68,flexDirection:'row',alignItems:'center',gap:spacing.md},back:{width:40,height:40,borderRadius:radius.md,backgroundColor:colors.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:colors.border},heading:{flex:1},title:{fontFamily:typography.bold,fontSize:19,color:colors.text},sub:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,marginTop:2},notice:{flexDirection:'row',alignItems:'center',gap:spacing.md,marginTop:spacing.sm},noticeIcon:{width:42,height:42,borderRadius:radius.md,backgroundColor:colors.navyLight,alignItems:'center',justifyContent:'center'},noticeTitle:{fontFamily:typography.semibold,fontSize:12,color:colors.text},noticeText:{fontFamily:typography.regular,fontSize:9.5,lineHeight:15,color:colors.mutedForeground,marginTop:3},statusCard:{backgroundColor:colors.primary,borderRadius:radius.lg,padding:spacing.lg,marginTop:spacing.lg},date:{fontFamily:typography.medium,fontSize:10,color:colors.orangeLight},status:{fontFamily:typography.bold,fontSize:24,color:colors.primaryForeground,marginTop:4},timeGrid:{flexDirection:'row',gap:spacing.md,marginTop:spacing.lg},timeBox:{flex:1,borderRadius:radius.md,backgroundColor:'rgba(255,255,255,.1)',padding:spacing.md},timeLabel:{fontFamily:typography.semibold,fontSize:8,color:colors.orangeLight},timeValue:{fontFamily:typography.bold,fontSize:15,color:colors.primaryForeground,marginTop:4},action:{minHeight:66,borderRadius:radius.lg,paddingHorizontal:spacing.lg,marginTop:spacing.md,flexDirection:'row',alignItems:'center',gap:spacing.md},checkIn:{backgroundColor:colors.success},checkOut:{backgroundColor:colors.secondary},disabled:{opacity:.4},actionTitle:{fontFamily:typography.bold,fontSize:13,color:colors.primaryForeground},actionSub:{fontFamily:typography.regular,fontSize:9,color:colors.primaryForeground,opacity:.86,marginTop:2},section:{fontFamily:typography.bold,fontSize:16,color:colors.text,marginTop:spacing.xl,marginBottom:spacing.md},empty:{fontFamily:typography.regular,fontSize:11,color:colors.mutedForeground,textAlign:'center'},record:{marginBottom:spacing.md},recordTop:{flexDirection:'row',alignItems:'center'},recordDate:{fontFamily:typography.bold,fontSize:12,color:colors.text,flex:1},badge:{fontFamily:typography.semibold,fontSize:9,color:colors.secondary,backgroundColor:colors.orangeLight,borderRadius:radius.pill,paddingHorizontal:9,paddingVertical:5},badgeDone:{color:colors.success,backgroundColor:'#EAF8EE'},recordTimes:{flexDirection:'row',justifyContent:'space-between',marginTop:spacing.md},recordText:{fontFamily:typography.medium,fontSize:10,color:colors.text},gps:{fontFamily:typography.regular,fontSize:8.5,color:colors.mutedForeground,marginTop:spacing.sm}});
