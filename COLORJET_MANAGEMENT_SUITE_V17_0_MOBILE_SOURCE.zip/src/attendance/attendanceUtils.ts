import { sha256 } from 'js-sha256';
import type { AttendanceAction } from '@/src/types/domain';

export function localDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function attendanceIdempotencyKey(employeeId: string, attendanceDate: string, action: AttendanceAction): string {
  return `att-${sha256(`${employeeId}|${attendanceDate}|${action}`).slice(0, 48)}`;
}

export function formatAttendanceTime(iso?: string): string {
  if (!iso) return 'Not recorded';
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
