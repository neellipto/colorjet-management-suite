import * as Location from 'expo-location';
import { Platform } from 'react-native';
import type { AttendanceLocation } from '@/src/types/domain';

const MAX_ACCEPTED_ACCURACY_M = 500;

function toNullableNumber(value: number | null | undefined): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

export async function getLocationPermissionState(): Promise<'granted' | 'denied' | 'undetermined'> {
  const response = await Location.getForegroundPermissionsAsync();
  return response.status;
}

export async function captureAttendanceLocation(): Promise<AttendanceLocation> {
  const servicesEnabled = await Location.hasServicesEnabledAsync();
  if (!servicesEnabled) {
    throw new Error('Device Location/GPS is turned off. Turn it on, then try again.');
  }
  if (Platform.OS === 'android') {
    const provider = await Location.getProviderStatusAsync();
    if (provider.gpsAvailable === false) {
      throw new Error('GPS provider is unavailable or disabled. Enable GPS and try again.');
    }
  }

  let permission = await Location.getForegroundPermissionsAsync();
  if (permission.status !== 'granted') {
    permission = await Location.requestForegroundPermissionsAsync();
  }
  if (permission.status !== 'granted') {
    throw new Error('Location permission is mandatory for attendance. Allow precise location permission and try again.');
  }
  if (Platform.OS === 'android' && permission.android?.accuracy !== 'fine') {
    throw new Error('Precise location is mandatory for attendance. Change Location permission from Approximate to Precise and try again.');
  }

  let position = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.Highest,
    mayShowUserSettingsDialog: true,
  });

  if ((position.coords.accuracy ?? Number.POSITIVE_INFINITY) > MAX_ACCEPTED_ACCURACY_M) {
    position = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.BestForNavigation,
      mayShowUserSettingsDialog: true,
    });
  }

  const latitude = position.coords.latitude;
  const longitude = position.coords.longitude;
  const accuracyM = toNullableNumber(position.coords.accuracy);
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    throw new Error('A valid GPS coordinate could not be captured. Move to an open area and try again.');
  }
  if (position.mocked) {
    throw new Error('Mock/fake GPS was detected. Attendance cannot be submitted from a simulated location.');
  }
  if (accuracyM !== null && accuracyM > MAX_ACCEPTED_ACCURACY_M) {
    throw new Error(`Location accuracy is too low (${Math.round(accuracyM)} m). Wait for GPS accuracy to improve and try again.`);
  }

  return {
    latitude: Number(latitude.toFixed(7)),
    longitude: Number(longitude.toFixed(7)),
    accuracyM: accuracyM === null ? null : Number(accuracyM.toFixed(2)),
    altitudeM: toNullableNumber(position.coords.altitude),
    heading: toNullableNumber(position.coords.heading),
    speedMps: toNullableNumber(position.coords.speed),
    capturedAt: new Date(position.timestamp || Date.now()).toISOString(),
    mocked: false,
  };
}
