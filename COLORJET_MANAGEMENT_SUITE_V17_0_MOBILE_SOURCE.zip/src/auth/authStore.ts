import AsyncStorage from '@react-native-async-storage/async-storage';
import { sha256 } from 'js-sha256';
import type { AppUser, UserRole } from '@/src/types/domain';
import { DATA_MODE, clearRemoteSession, getRemoteSession, remoteLogin, remoteLogout, type RemoteApiUser } from '@/src/services/apiClient';

const OWNER_KEY = '@colorjet/erp/v17/auth/owner';
const SESSION_KEY = '@colorjet/erp/v17/auth/session';

interface OwnerCredential { user: AppUser; salt: string; passwordHash: string; }

const bytesToHex = (bytes: Uint8Array) => Array.from(bytes).map(value => value.toString(16).padStart(2, '0')).join('');

function createSalt(): string {
  const bytes = new Uint8Array(24);
  const nativeCrypto = (globalThis as typeof globalThis & { crypto?: { getRandomValues?: (array: Uint8Array) => Uint8Array } }).crypto;
  if (nativeCrypto?.getRandomValues) nativeCrypto.getRandomValues(bytes);
  else {
    let state = (Date.now() ^ Math.floor(Math.random() * 0x7fffffff)) >>> 0;
    for (let index = 0; index < bytes.length; index += 1) {
      state ^= state << 13; state ^= state >>> 17; state ^= state << 5;
      bytes[index] = (state ^ Math.floor(Math.random() * 256)) & 0xff;
    }
  }
  return bytesToHex(bytes);
}

const hash = (salt: string, password: string): string => sha256(`${salt}:${password}`);

function normalizeRole(role: string): UserRole {
  const key = role.trim().toLowerCase();
  if (key === 'service_manager' || key === 'service_control') return 'service_control';
  if (key === 'marketing') return 'marketing';
  if (['owner','admin','manager','accounts','sales','engineer','store','office_staff','customer'].includes(key)) return key as UserRole;
  return 'office_staff';
}

function mapRemoteUser(user: RemoteApiUser): AppUser {
  const role = normalizeRole(user.role);
  return {
    id: String(user.id),
    name: user.name || user.email || 'COLORJET User',
    email: user.email || '',
    phone: user.phone || '',
    role,
    roleTitle: role === 'customer' ? 'Customer Portal User' : role.replaceAll('_', ' ').replace(/\b\w/g, value => value.toUpperCase()),
    employeeCode: user.employee_id || (role === 'customer' ? `CUSTOMER-${user.customer_id ?? ''}` : ''),
    department: user.department || (role === 'customer' ? 'Customer' : ''),
    customerId: user.customer_id ?? null,
    mustChangePassword: Boolean(user.must_change_password),
    isActive: true,
  };
}

export async function hasOwner(): Promise<boolean> {
  if (DATA_MODE === 'remote') return true;
  return Boolean(await AsyncStorage.getItem(OWNER_KEY));
}

export async function createOwner(input: { name: string; email: string; phone: string; password: string }): Promise<AppUser> {
  if (DATA_MODE === 'remote') throw new Error('Create the production Owner from the cPanel installer or Users & Access module.');
  if (await hasOwner()) throw new Error('Owner account already exists.');
  const salt = createSalt();
  const user: AppUser = {
    id: `owner-${Date.now()}`,
    name: input.name.trim(),
    email: input.email.trim().toLowerCase(),
    phone: input.phone.trim(),
    role: 'owner',
    roleTitle: 'Founder & Managing Director',
    employeeCode: 'OWNER-001',
    department: 'Management',
    customerId: null,
    mustChangePassword: false,
    isActive: true,
  };
  const credential: OwnerCredential = { user, salt, passwordHash: hash(salt, input.password) };
  await AsyncStorage.multiSet([[OWNER_KEY, JSON.stringify(credential)], [SESSION_KEY, user.id]]);
  return user;
}

export async function login(emailOrPhone: string, password: string): Promise<AppUser> {
  if (DATA_MODE === 'remote') return mapRemoteUser((await remoteLogin(emailOrPhone, password)).user);
  const raw = await AsyncStorage.getItem(OWNER_KEY);
  if (!raw) throw new Error('First Owner Setup is required.');
  const credential = JSON.parse(raw) as OwnerCredential;
  const identity = emailOrPhone.trim().toLowerCase();
  const matchesIdentity = identity === credential.user.email.toLowerCase() || identity === credential.user.phone.toLowerCase();
  if (!matchesIdentity || hash(credential.salt, password) !== credential.passwordHash) throw new Error('Invalid login information.');
  await AsyncStorage.setItem(SESSION_KEY, credential.user.id);
  return credential.user;
}

export async function getSessionUser(): Promise<AppUser | null> {
  if (DATA_MODE === 'remote') {
    const session = await getRemoteSession();
    return session?.user ? mapRemoteUser(session.user) : null;
  }
  const entries = await AsyncStorage.multiGet([OWNER_KEY, SESSION_KEY]);
  const ownerValue = entries[0]?.[1]; const sessionValue = entries[1]?.[1];
  if (!ownerValue || !sessionValue) return null;
  const credential = JSON.parse(ownerValue) as OwnerCredential;
  return credential.user.id === sessionValue ? credential.user : null;
}

export async function logout(): Promise<void> {
  if (DATA_MODE === 'remote') {
    try { await remoteLogout(); } catch { await clearRemoteSession(); }
    return;
  }
  await AsyncStorage.removeItem(SESSION_KEY);
}
