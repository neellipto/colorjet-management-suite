import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Stack, useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { useAppData } from '@/src/data/AppDataProvider';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';

const links = [
  ['foreign-purchase','Foreign Purchase','globe-outline'],
  ['warranty-register','Warranty Board RMA','shield-checkmark-outline'],
  ['shipment','Shipment & Customs','boat-outline'],
  ['warehouse-receiving','Warehouse Receiving','home-outline'],
  ['supplier-claims','Supplier Claims','alert-circle-outline'],
  ['landed-cost','Landed Cost','calculator-outline'],
] as const;

export function ImportControlCenterScreen(){
  const router=useRouter();
  const {getRecords}=useAppData();
  const metrics=[
    ['Purchase Files',getRecords('foreign-purchase').length],
    ['Open RMA',getRecords('warranty-register').filter(r=>!['closed','resolved'].includes(r.status)).length],
    ['Shipments',getRecords('shipment').length],
    ['Open Claims',getRecords('supplier-claims').filter(r=>!['settled','closed','rejected'].includes(r.status)).length],
  ] as const;
  return <Screen><Stack.Screen options={{headerShown:false}}/><View style={styles.header}><Pressable onPress={()=>router.back()} style={styles.back}><Ionicons name="arrow-back" size={22} color={colors.primary}/></Pressable><View style={styles.heading}><Text style={styles.title}>Import Control Center</Text><Text style={styles.sub}>Purchase, warranty, shipment, receiving and claim operations</Text></View></View>
    <View style={styles.metrics}>{metrics.map(([label,value])=><Card key={label} style={styles.metric}><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></Card>)}</View>
    <Text style={styles.section}>Quick Operations</Text>
    {links.map(([key,title,icon])=><Pressable key={key} style={styles.link} onPress={()=>router.push({pathname:'/module/[key]',params:{key}})}><View style={styles.linkIcon}><Ionicons name={icon} size={20} color={colors.primary}/></View><Text style={styles.linkTitle}>{title}</Text><Ionicons name="chevron-forward" size={19} color={colors.mutedForeground}/></Pressable>)}
  </Screen>;
}
const styles=StyleSheet.create({header:{minHeight:68,flexDirection:'row',alignItems:'center',gap:spacing.md},back:{width:40,height:40,borderRadius:radius.md,backgroundColor:colors.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:colors.border},heading:{flex:1},title:{fontFamily:typography.bold,fontSize:19,color:colors.text},sub:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,marginTop:2},metrics:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',gap:spacing.md,marginTop:spacing.md},metric:{width:'47%',minHeight:96},metricValue:{fontFamily:typography.bold,fontSize:24,color:colors.primary},metricLabel:{fontFamily:typography.medium,fontSize:10,color:colors.mutedForeground,marginTop:5},section:{fontFamily:typography.bold,fontSize:16,color:colors.text,marginTop:spacing.xl,marginBottom:spacing.md},link:{minHeight:62,borderRadius:radius.lg,backgroundColor:colors.card,borderWidth:1,borderColor:colors.border,paddingHorizontal:spacing.md,flexDirection:'row',alignItems:'center',gap:spacing.md,marginBottom:spacing.sm},linkIcon:{width:38,height:38,borderRadius:radius.md,backgroundColor:colors.navyLight,alignItems:'center',justifyContent:'center'},linkTitle:{fontFamily:typography.semibold,fontSize:12,color:colors.text,flex:1}});
