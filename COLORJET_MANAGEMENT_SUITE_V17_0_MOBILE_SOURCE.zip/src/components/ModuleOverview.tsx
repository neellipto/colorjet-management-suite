import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { AppHeader } from '@/src/components/ui/AppHeader';
import { ModuleCard } from '@/src/components/ui/ModuleCard';
import { SectionHeader } from '@/src/components/ui/SectionHeader';
import { MODULES } from '@/src/core/moduleRegistry';
import { useAppData } from '@/src/data/AppDataProvider';
import type { ModuleGroup } from '@/src/types/domain';
import { spacing } from '@/src/theme/tokens';
export function ModuleOverview({title,subtitle,groups}:{title:string;subtitle:string;groups:ModuleGroup[]}){const router=useRouter();const {currentUser,getRecords}=useAppData();const modules=MODULES.filter(m=>groups.includes(m.group)&&currentUser&&m.roles.includes(currentUser.role));return <Screen><AppHeader title={title} subtitle={subtitle} onProfile={()=>router.push('/profile')}/><SectionHeader title="Modules" caption={`${modules.length} available modules`}/><View style={styles.grid}>{modules.map(module=><ModuleCard key={module.key} module={module} count={getRecords(module.key).length} onPress={()=>router.push({pathname:'/module/[key]',params:{key:module.key}})}/>)}</View></Screen>}
const styles=StyleSheet.create({grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',gap:spacing.md}});
