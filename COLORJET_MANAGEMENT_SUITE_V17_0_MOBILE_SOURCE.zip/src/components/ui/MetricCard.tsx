/** UI LOCKED FILE */
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { IconName } from '@/src/types/domain';
import { Card } from './Card';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
export function MetricCard({label,value,icon,tone='primary'}:{label:string;value:string|number;icon:IconName;tone?:'primary'|'orange'|'success'|'info'}){const c=tone==='orange'?colors.secondary:tone==='success'?colors.success:tone==='info'?colors.info:colors.primary;return <Card style={styles.card}><View style={[styles.icon,{backgroundColor:`${c}18`}]}><Ionicons name={icon} size={20} color={c}/></View><Text style={styles.value}>{value}</Text><Text style={styles.label}>{label}</Text></Card>}
const styles=StyleSheet.create({card:{width:'48%',minHeight:126},icon:{width:38,height:38,borderRadius:radius.md,alignItems:'center',justifyContent:'center'},value:{fontFamily:typography.bold,fontSize:23,color:colors.text,marginTop:spacing.md},label:{fontFamily:typography.medium,fontSize:12,color:colors.mutedForeground,marginTop:2}});
