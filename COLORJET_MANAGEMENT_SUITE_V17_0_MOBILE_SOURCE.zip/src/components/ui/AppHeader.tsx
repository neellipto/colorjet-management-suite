/** UI LOCKED FILE */
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
export function AppHeader({title,subtitle,onProfile,onNotification}:{title:string;subtitle?:string;onProfile?:()=>void;onNotification?:()=>void}){
 return <View style={styles.row}><View style={styles.copy}><Text numberOfLines={1} style={styles.title}>{title}</Text>{subtitle?<Text numberOfLines={1} style={styles.subtitle}>{subtitle}</Text>:null}</View><View style={styles.actions}>{onNotification?<Pressable onPress={onNotification} style={styles.icon}><Ionicons name="notifications-outline" size={21} color={colors.primary}/></Pressable>:null}{onProfile?<Pressable onPress={onProfile} style={[styles.icon,styles.profile]}><Ionicons name="person-outline" size={21} color={colors.primaryForeground}/></Pressable>:null}</View></View>
}
const styles=StyleSheet.create({row:{minHeight:64,flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:spacing.sm},copy:{flex:1,paddingRight:spacing.md},title:{fontFamily:typography.bold,fontSize:22,color:colors.text},subtitle:{marginTop:2,fontFamily:typography.regular,fontSize:12,color:colors.mutedForeground},actions:{flexDirection:'row',gap:spacing.sm},icon:{width:40,height:40,borderRadius:radius.md,backgroundColor:colors.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:colors.border},profile:{backgroundColor:colors.primary,borderColor:colors.primary}});
