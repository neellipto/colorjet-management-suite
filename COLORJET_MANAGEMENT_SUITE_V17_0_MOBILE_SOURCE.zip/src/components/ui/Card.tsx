/** UI LOCKED FILE */
import React from 'react';
import { StyleSheet, View, type ViewProps } from 'react-native';
import { colors, radius, shadow, spacing } from '@/src/theme/tokens';
export function Card({style,...props}:ViewProps){return <View {...props} style={[styles.card,style]}/>}
const styles=StyleSheet.create({card:{backgroundColor:colors.card,borderRadius:radius.lg,borderWidth:1,borderColor:colors.border,padding:spacing.lg,...shadow.card}});
