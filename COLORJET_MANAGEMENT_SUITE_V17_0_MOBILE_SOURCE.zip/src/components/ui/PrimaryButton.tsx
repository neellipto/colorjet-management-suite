/** UI LOCKED FILE */
import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';
export function PrimaryButton({title,onPress,loading=false,variant='primary'}:{title:string;onPress:()=>void;loading?:boolean;variant?:'primary'|'secondary'|'danger'}){const bg=variant==='secondary'?colors.secondary:variant==='danger'?colors.destructive:colors.primary;return <Pressable disabled={loading} onPress={onPress} style={({pressed})=>[styles.button,{backgroundColor:bg},pressed&&styles.pressed]}>{loading?<ActivityIndicator color="#FFF"/>:<Text style={styles.text}>{title}</Text>}</Pressable>}
const styles=StyleSheet.create({button:{minHeight:50,borderRadius:radius.md,alignItems:'center',justifyContent:'center',paddingHorizontal:spacing.lg},pressed:{transform:[{scale:.99}],opacity:.9},text:{fontFamily:typography.semibold,fontSize:14,color:colors.primaryForeground}});
