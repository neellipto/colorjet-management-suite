/** UI LOCKED FILE */
import React from 'react';
import { ScrollView, StyleSheet, View, type ScrollViewProps, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing } from '@/src/theme/tokens';
export function Screen({children,scroll=true,contentStyle,...props}:{children:React.ReactNode;scroll?:boolean;contentStyle?:ViewStyle}&ScrollViewProps){
  return <SafeAreaView edges={['top','left','right']} style={styles.safe}>{scroll?<ScrollView {...props} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={[styles.content,contentStyle]}>{children}</ScrollView>:<View style={[styles.content,styles.flex,contentStyle]}>{children}</View>}</SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:colors.background},content:{paddingHorizontal:spacing.lg,paddingBottom:96},flex:{flex:1}});
