/** UI LOCKED FILE */
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, spacing, typography } from '@/src/theme/tokens';
export function SectionHeader({title,caption}:{title:string;caption?:string}){return <View style={styles.wrap}><Text style={styles.title}>{title}</Text>{caption?<Text style={styles.caption}>{caption}</Text>:null}</View>}
const styles=StyleSheet.create({wrap:{marginTop:spacing.xl,marginBottom:spacing.md},title:{fontFamily:typography.bold,fontSize:17,color:colors.text},caption:{fontFamily:typography.regular,fontSize:11,color:colors.mutedForeground,marginTop:2}});
