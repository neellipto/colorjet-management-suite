import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { AppHeader } from '@/src/components/ui/AppHeader';
import { MetricCard } from '@/src/components/ui/MetricCard';
import { ModuleCard } from '@/src/components/ui/ModuleCard';
import { SectionHeader } from '@/src/components/ui/SectionHeader';
import { Card } from '@/src/components/ui/Card';
import { useAppData } from '@/src/data/AppDataProvider';
import { MODULE_MAP } from '@/src/core/moduleRegistry';
import type { CustomerPortalDashboard, ModuleDefinition } from '@/src/types/domain';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';

const quickKeys = ['invoices', 'service-tickets', 'customer-ledger', 'customer-machines', 'agreements-emi', 'notifications'];
const taka = (value: number | string | undefined) => `৳${Number(value ?? 0).toLocaleString('en-BD', { maximumFractionDigits: 0 })}`;

function isCustomerDashboard(value: CustomerPortalDashboard | Record<string, unknown> | null): value is CustomerPortalDashboard {
  return Boolean(value && 'summary' in value && 'customer' in value);
}

export function CustomerDashboardScreen() {
  const router = useRouter();
  const { currentUser, getRecords, remoteDashboard, refreshRemoteData, isRefreshing } = useAppData();
  const data = isCustomerDashboard(remoteDashboard) ? remoteDashboard : null;
  const modules = quickKeys.map(key => MODULE_MAP[key]).filter((item): item is ModuleDefinition => Boolean(item));
  const customerName = data?.customer.company_name || data?.customer.name || currentUser?.name || 'Customer';
  const summary = data?.summary;

  return <Screen refreshControl={undefined}>
    <AppHeader
      title={`Welcome, ${customerName}`}
      subtitle="Secure COLORJET Customer Portal"
      onProfile={() => router.push('/profile')}
      onNotification={() => router.push({ pathname: '/module/[key]', params: { key: 'notifications' } })}
    />
    <View style={styles.hero}>
      <View style={styles.heroCopy}>
        <Text style={styles.eyebrow}>COLORJET Bangladesh</Text>
        <Text style={styles.heroTitle}>Customer Service Dashboard</Text>
        <Text style={styles.tagline}>Quality • Commitment • Service</Text>
      </View>
      <View style={styles.heroIcon}><Ionicons name="shield-checkmark-outline" size={31} color={colors.secondary}/></View>
    </View>

    <View style={styles.identity}>
      <View style={{ flex: 1 }}>
        <Text style={styles.identityName}>{customerName}</Text>
        <Text style={styles.identityMeta}>{data?.customer.phone || currentUser?.phone || 'Linked customer account'}</Text>
      </View>
      <Pressable disabled={isRefreshing} onPress={() => refreshRemoteData()} style={styles.refresh}>
        <Ionicons name="refresh" size={18} color={colors.primary}/>
        <Text style={styles.refreshText}>{isRefreshing ? 'Syncing' : 'Refresh'}</Text>
      </Pressable>
    </View>

    <SectionHeader title="Account Overview" caption="Only records linked to your customer account are shown"/>
    <View style={styles.metrics}>
      <MetricCard label="Total Due" value={taka(summary?.total_due)} icon="wallet-outline" tone="orange"/>
      <MetricCard label="Open Tickets" value={summary?.open_tickets ?? getRecords('service-tickets').length} icon="ticket-outline"/>
      <MetricCard label="Registered Machines" value={summary?.total_machines ?? getRecords('customer-machines').length} icon="hardware-chip-outline" tone="info"/>
      <MetricCard label="Active Warranty" value={summary?.warranty_active ?? 0} icon="shield-checkmark-outline" tone="success"/>
    </View>

    {summary && Number(summary.overdue_due) > 0 ? <Card style={styles.alertCard}>
      <View style={styles.alertIcon}><Ionicons name="alert-circle-outline" size={22} color={colors.secondary}/></View>
      <View style={{ flex: 1 }}><Text style={styles.alertTitle}>Overdue balance</Text><Text style={styles.alertText}>{taka(summary.overdue_due)} requires payment follow-up.</Text></View>
    </Card> : null}

    <SectionHeader title="My COLORJET Services" caption="Invoices, machines, warranty, service and account records"/>
    <View style={styles.grid}>{modules.map(module => <ModuleCard key={module.key} module={module} count={getRecords(module.key).length} onPress={() => router.push({ pathname: '/module/[key]', params: { key: module.key } })}/>)}</View>

    <Card style={styles.support}>
      <View style={styles.supportIcon}><Ionicons name="headset-outline" size={25} color={colors.primaryForeground}/></View>
      <View style={{ flex: 1 }}><Text style={styles.supportTitle}>Need technical support?</Text><Text style={styles.supportText}>Create a Service Ticket with machine model, serial number and problem details.</Text></View>
      <Pressable onPress={() => router.push({ pathname: '/module/[key]', params: { key: 'service-tickets' } })} style={styles.supportButton}><Ionicons name="arrow-forward" size={18} color={colors.secondary}/></Pressable>
    </Card>
  </Screen>;
}

const styles = StyleSheet.create({
  hero: { minHeight: 132, borderRadius: radius.lg, backgroundColor: colors.primary, padding: spacing.lg, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroCopy: { flex: 1, paddingRight: spacing.md },
  eyebrow: { fontFamily: typography.semibold, fontSize: 10, color: colors.orangeLight, textTransform: 'uppercase', letterSpacing: .7 },
  heroTitle: { fontFamily: typography.bold, fontSize: 21, color: colors.primaryForeground, marginTop: 6 },
  tagline: { fontFamily: typography.medium, fontSize: 11, color: colors.orangeLight, marginTop: 7 },
  heroIcon: { width: 60, height: 60, borderRadius: radius.lg, backgroundColor: 'rgba(255,255,255,.1)', alignItems: 'center', justifyContent: 'center' },
  identity: { marginTop: spacing.md, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.md, flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  identityName: { fontFamily: typography.semibold, fontSize: 14, color: colors.text },
  identityMeta: { fontFamily: typography.regular, fontSize: 10, color: colors.mutedForeground, marginTop: 3 },
  refresh: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: radius.md, backgroundColor: colors.navyLight, paddingHorizontal: 11, paddingVertical: 9 },
  refreshText: { fontFamily: typography.semibold, fontSize: 10, color: colors.primary },
  metrics: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: spacing.md },
  alertCard: { marginTop: spacing.md, flexDirection: 'row', alignItems: 'center', gap: spacing.md, borderColor: colors.orangeLight },
  alertIcon: { width: 42, height: 42, borderRadius: radius.md, backgroundColor: colors.orangeLight, alignItems: 'center', justifyContent: 'center' },
  alertTitle: { fontFamily: typography.semibold, fontSize: 13, color: colors.text },
  alertText: { fontFamily: typography.regular, fontSize: 11, color: colors.mutedForeground, marginTop: 3 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: spacing.md },
  support: { marginTop: spacing.xl, backgroundColor: colors.primary, borderColor: colors.primary, flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  supportIcon: { width: 48, height: 48, borderRadius: radius.md, backgroundColor: 'rgba(255,255,255,.12)', alignItems: 'center', justifyContent: 'center' },
  supportTitle: { fontFamily: typography.semibold, fontSize: 13, color: colors.primaryForeground },
  supportText: { fontFamily: typography.regular, fontSize: 10, lineHeight: 15, color: colors.orangeLight, marginTop: 3 },
  supportButton: { width: 38, height: 38, borderRadius: radius.md, backgroundColor: colors.orangeLight, alignItems: 'center', justifyContent: 'center' },
});
