/**
 * UI LOCKED FILE — recovered visual tokens from the approved standalone APK.
 * Do not edit when adding modules. Module screens must consume these tokens.
 */
export const colors = Object.freeze({
  text: '#1C1C1E',
  tint: '#1A237E',
  background: '#F0F2F5',
  foreground: '#1C1C1E',
  card: '#FFFFFF',
  cardForeground: '#1C1C1E',
  primary: '#1A237E',
  primaryForeground: '#FFFFFF',
  secondary: '#F57C00',
  secondaryForeground: '#FFFFFF',
  muted: '#E5E5EA',
  mutedForeground: '#8E8E93',
  accent: '#FFF3E0',
  accentForeground: '#F57C00',
  destructive: '#FF3B30',
  destructiveForeground: '#FFFFFF',
  border: '#E5E5EA',
  input: '#FFFFFF',
  success: '#34C759',
  successForeground: '#FFFFFF',
  warning: '#FF9500',
  warningForeground: '#FFFFFF',
  info: '#007AFF',
  infoForeground: '#FFFFFF',
  navy: '#1A237E',
  orange: '#F57C00',
  navyLight: '#E8EAF6',
  orangeLight: '#FFF3E0',
} as const);

export const radius = Object.freeze({ xs: 6, sm: 8, md: 10, lg: 14, xl: 18, pill: 999 });
export const spacing = Object.freeze({ xxs: 4, xs: 6, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24 });
export const typography = Object.freeze({
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semibold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
  tabLabelSize: 10,
  navTitleSize: 17,
} as const);
export const shadow = Object.freeze({
  card: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  pressed: { transform: [{ scale: 0.985 }] },
});
export const UI_LOCK_VERSION = 'APK-BASELINE-2026-07-13/V15-ATTENDANCE';
