import AsyncStorage from '@react-native-async-storage/async-storage';

const MIGRATION_MARKER = '@colorjet/erp/v14/legacy-cleaned';
const OLD_SUFFIXES = ['_data','_user','_token','_seed','_seed_version'];
const OLD_EXACT_KEYS = [
  'customers','products','categories','invoices','payments','serviceLogs','stockMoves','deliveries','expenses','notifications','catalogAssets','company','branding','integrations','notificationSettings'
];

/** Removes only old COLORJET business state from the previous APK namespace. */
export async function removeLegacyAppData(): Promise<number> {
  if (await AsyncStorage.getItem(MIGRATION_MARKER)) return 0;
  const keys = await AsyncStorage.getAllKeys();
  const targets = keys.filter((key) => {
    const low = key.toLowerCase();
    if (key.startsWith('@colorjet/erp/v14/')) return false;
    return OLD_EXACT_KEYS.includes(key) || OLD_SUFFIXES.some((suffix) => key.endsWith(suffix)) ||
      ((low.includes('colorjet') || low.includes('managementsuite')) && !low.includes('/v14/'));
  });
  if (targets.length) await AsyncStorage.multiRemove(targets);
  await AsyncStorage.setItem(MIGRATION_MARKER, new Date().toISOString());
  return targets.length;
}
