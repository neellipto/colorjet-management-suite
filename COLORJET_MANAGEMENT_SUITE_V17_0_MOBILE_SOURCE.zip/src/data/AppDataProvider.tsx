import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type {
  AppUser,
  AttendanceAction,
  AttendanceLocation,
  AttendanceRecord,
  CustomerPortalDashboard,
  ModuleRecord,
  PersistedState,
  UserNotification,
  UserRole,
} from '@/src/types/domain';
import { removeLegacyAppData } from './legacyCleanup';
import { loadState, resetState, saveState } from './storage';
import { createOwner, getSessionUser, hasOwner, login, logout } from '@/src/auth/authStore';
import { attendanceIdempotencyKey, localDateKey } from '@/src/attendance/attendanceUtils';
import { assertAttendancePunchAllowed } from '@/src/attendance/attendanceRules';
import { syncAttendancePunch } from '@/src/attendance/attendanceSync';
import { apiGet, apiPost, DATA_MODE, toSnakeCasePayload } from '@/src/services/apiClient';
import { EMPLOYEES } from '@/src/employees/employeeData';
import { MODULE_MAP } from '@/src/core/moduleRegistry';

interface ContextValue {
  ready: boolean;
  ownerExists: boolean;
  currentUser: AppUser | null;
  state: PersistedState | null;
  remoteDashboard: CustomerPortalDashboard | Record<string, unknown> | null;
  isRefreshing: boolean;
  setupOwner: (input: { name: string; email: string; phone: string; password: string }) => Promise<void>;
  signIn: (identity: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshRemoteData: () => Promise<void>;
  getRecords: (moduleKey: string) => ModuleRecord[];
  addRecord: (moduleKey: string, values: Record<string, string | number>) => Promise<void>;
  deleteRecord: (moduleKey: string, id: string) => Promise<void>;
  resetBusinessData: () => Promise<void>;
  punchAttendance: (action: AttendanceAction, location: AttendanceLocation) => Promise<AttendanceRecord>;
}
const Context = createContext<ContextValue | null>(null);

const EMPLOYEE_MODULE_KEYS = new Set(['employee-directory', 'employee-verification', 'employee-id-cards']);
const employeeModuleRecords = (moduleKey: string): ModuleRecord[] => EMPLOYEES.map((employee, index) => ({
  id: `${moduleKey}-${employee.code}`,
  moduleKey,
  title: employee.name,
  reference: employee.code,
  status: employee.verificationStatus.toLowerCase(),
  date: '',
  notes: employee.designation,
  createdAt: new Date(2026, 6, 13, 0, 0, index).toISOString(),
  updatedAt: new Date(2026, 6, 13, 0, 0, index).toISOString(),
  values: { department: employee.department, role: employee.role, phone: employee.phone },
}));

type ApiList = { items?: Record<string, unknown>[]; unread?: number; pagination?: Record<string, unknown> };
type ApiLedger = ApiList & { customer?: Record<string, unknown>; closing_balance?: number; from?: string; to?: string };

const REMOTE_CREATABLE_MODULES = new Set(['office-tasks', 'customers', 'products', 'service-tickets', 'expenses', 'supplier-claims', 'notifications']);

const REMOTE_LISTS_BY_ROLE: Partial<Record<UserRole, [string, string][]>> = {
  owner: [['office-tasks', 'tasks'], ['service-tickets', 'service-tickets'], ['customers', 'customers'], ['invoices', 'invoices'], ['products', 'products'], ['expenses', 'expenses'], ['supplier-claims', 'supplier-claims'], ['employee-directory', 'employee-cards']],
  admin: [['office-tasks', 'tasks'], ['service-tickets', 'service-tickets'], ['customers', 'customers'], ['invoices', 'invoices'], ['products', 'products'], ['expenses', 'expenses'], ['supplier-claims', 'supplier-claims'], ['employee-directory', 'employee-cards']],
  manager: [['office-tasks', 'tasks'], ['service-tickets', 'service-tickets'], ['customers', 'customers'], ['invoices', 'invoices'], ['products', 'products'], ['expenses', 'expenses'], ['supplier-claims', 'supplier-claims'], ['employee-directory', 'employee-cards']],
  accounts: [['customers', 'customers'], ['invoices', 'invoices'], ['expenses', 'expenses'], ['supplier-claims', 'supplier-claims'], ['employee-directory', 'employee-cards']],
  sales: [['office-tasks', 'tasks'], ['customers', 'customers'], ['invoices', 'invoices'], ['employee-directory', 'employee-cards']],
  marketing: [['office-tasks', 'tasks'], ['customers', 'customers'], ['invoices', 'invoices']],
  engineer: [['service-tickets', 'service-tickets'], ['employee-directory', 'employee-cards']],
  service_control: [['service-tickets', 'service-tickets'], ['products', 'products'], ['employee-directory', 'employee-cards']],
  store: [['products', 'products'], ['supplier-claims', 'supplier-claims'], ['employee-directory', 'employee-cards']],
  office_staff: [['office-tasks', 'tasks'], ['customers', 'customers'], ['employee-directory', 'employee-cards']],
};

function scalar(value: unknown): string | number {
  if (typeof value === 'number' || typeof value === 'string') return value;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (value === null || value === undefined) return '';
  try { return JSON.stringify(value); } catch { return String(value); }
}

function recordValues(row: Record<string, unknown>): Record<string, string | number> {
  return Object.fromEntries(Object.entries(row).map(([key, value]) => [key, scalar(value)]));
}

function firstText(row: Record<string, unknown>, keys: string[], fallback = ''): string {
  for (const key of keys) {
    const value = row[key];
    if (value !== undefined && value !== null && String(value).trim() !== '') return String(value);
  }
  return fallback;
}

function firstNumber(row: Record<string, unknown>, keys: string[]): number | undefined {
  for (const key of keys) {
    const value = row[key];
    if (value !== undefined && value !== null && value !== '' && Number.isFinite(Number(value))) return Number(value);
  }
  return undefined;
}

function apiRowToRecord(moduleKey: string, row: Record<string, unknown>, index: number): ModuleRecord {
  const module = MODULE_MAP[moduleKey];
  const idValue = firstText(row, ['id', 'uuid', 'record_id', 'employee_code', 'invoice_number', 'ticket_number', 'claim_number'], `${index + 1}`);
  const title = firstText(row, [
    'title', 'name', 'company_name', 'customer_name', 'supplier_name', 'product_name', 'machine_name', 'machine_model',
    'subject', 'description', 'particulars', 'invoice_number', 'ticket_number', 'agreement_number', 'claim_number', 'employee_code',
  ], module?.title ?? moduleKey);
  const reference = firstText(row, [
    'reference', 'invoice_number', 'ticket_number', 'agreement_number', 'claim_number', 'asset_code', 'employee_code',
    'serial_number', 'sku', 'product_code', 'task_number', 'voucher_number', 'id',
  ], idValue);
  const createdAt = firstText(row, ['created_at', 'createdAt', 'date', 'invoice_date'], new Date().toISOString());
  const updatedAt = firstText(row, ['updated_at', 'updatedAt'], createdAt);
  const notesText = firstText(row, ['notes', 'problem_description', 'message', 'description', 'resolution', 'address', 'designation']);
  return {
    id: `${moduleKey}-${idValue}`,
    moduleKey,
    title,
    reference,
    status: firstText(row, ['status', 'attendance_status', 'condition_status', 'is_read'], 'active').toLowerCase().replaceAll(' ', '_'),
    amount: firstNumber(row, ['balance', 'total', 'amount', 'claim_amount', 'remaining_amount', 'service_cost', 'regular_price', 'offer_price']),
    date: firstText(row, ['date', 'invoice_date', 'due_date', 'visit_date', 'created_at', 'installation_date']).slice(0, 10),
    notes: notesText,
    createdAt,
    updatedAt,
    values: recordValues(row),
    apiEndpoint: module?.apiEndpoint,
    mutationKey: module?.mutationKey,
    auditAction: module?.auditAction,
  };
}

function apiNotifications(payload: ApiList): UserNotification[] {
  return (payload.items ?? []).map((row, index) => ({
    id: String(row.id ?? `remote-notification-${index}`),
    title: String(row.title ?? 'COLORJET Notification'),
    body: String(row.message ?? row.body ?? ''),
    moduleKey: String(row.related_module ?? 'notifications'),
    recordId: String(row.related_record_id ?? row.id ?? ''),
    status: Number(row.is_read ?? 0) === 1 ? 'read' : 'unread',
    priority: /urgent/i.test(String(row.priority ?? '')) ? 'urgent' : /high|important/i.test(String(row.priority ?? '')) ? 'important' : 'normal',
    createdAt: String(row.created_at ?? new Date().toISOString()),
    readAt: row.read_at ? String(row.read_at) : undefined,
  }));
}

function customerPayload(moduleKey: string, values: Record<string, string | number>): Record<string, string | number> {
  const payload = toSnakeCasePayload(values);
  if (moduleKey === 'service-tickets') {
    return {
      machine_asset_id: Number(values.machineAssetId || 0),
      machine_model: values.machineModel || values.machine || '',
      serial_number: values.serialNumber || '',
      issue_category: values.issueCategory || 'Customer Support',
      problem_description: values.problemDescription || values.problem || values.notes || '',
      priority: values.priority || 'normal',
      is_warranty: String(values.isWarranty || '').toLowerCase() === 'yes' ? 1 : Number(values.isWarranty || 0),
    };
  }
  return payload;
}

function staffPayload(moduleKey: string, values: Record<string, string | number>): Record<string, string | number> {
  const payload = toSnakeCasePayload(values);
  if (moduleKey === 'customers') {
    return {
      ...payload,
      name: values.contactPerson || values.companyName || values.customerId || 'Customer',
      company_name: values.companyName || '',
      phone: values.phone || '',
      phone2: values.alternativePhone || '',
      address: values.billingAddress || '',
      customer_type: values.customerType || 'company',
    };
  }
  if (moduleKey === 'office-tasks') {
    return {
      ...payload,
      title: values.title || '',
      description: values.description || values.notes || '',
      assigned_to: values.assignedEmployee || '',
      due_date: values.dueDate || '',
    };
  }
  if (moduleKey === 'service-tickets') {
    return {
      ...payload,
      customer_id: Number(values.customerId || values.customer || 0),
      machine_model: values.machineModel || values.machine || '',
      serial_number: values.serialNumber || '',
      issue_category: values.issueCategory || 'Service',
      problem_description: values.problemDescription || values.problem || values.notes || '',
    };
  }
  if (moduleKey === 'notifications') {
    return {
      title: values.title || '',
      message: values.body || values.message || '',
      audience_type: values.audienceType || 'all_users',
      audience: values.audience || '',
      priority: values.priority || 'normal',
      action_url: values.deepLink || '',
    };
  }
  if (moduleKey === 'products') {
    return {
      name: values.productName || '', sku: values.sku || '', brand: values.brand || '', model: values.model || '', unit: values.unit || 'pcs',
      purchase_price: Number(values.purchasePrice || 0), selling_price: Number(values.sellingPrice || 0), opening_stock: Number(values.openingStock || 0),
      min_stock: Number(values.minimumStockLevel || 0), description: values.notes || '', is_service: 0,
    };
  }
  if (moduleKey === 'expenses') {
    return {
      date: values.expenseDate || '', category: values.category || '', description: values.notes || values.payee || '', amount: Number(values.amount || 0),
      cash_bank_account_id: Number(values.cashBankAccount || 0), payment_mode: values.paymentMethod || '', reference: values.reference || '',
    };
  }
  if (moduleKey === 'supplier-claims') {
    return {
      ...payload,
      supplier_id: Number(values.supplierId || values.supplier || 0),
      claim_amount: Number(values.claimAmount || values.amount || 0),
      claim_type: values.claimType || 'shortage',
      quantity: Number(values.claimQty || 0),
    };
  }
  return payload;
}

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [ownerExists, setOwnerExists] = useState(false);
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [state, setState] = useState<PersistedState | null>(null);
  const [remoteDashboard, setRemoteDashboard] = useState<CustomerPortalDashboard | Record<string, unknown> | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const attendanceMutationLock = useRef(false);

  const persist = useCallback(async (next: PersistedState) => {
    setState(next);
    await saveState(next);
  }, []);

  const loadRemoteDataForUser = useCallback(async (user: AppUser, baseState?: PersistedState) => {
    if (DATA_MODE !== 'remote') return;
    setIsRefreshing(true);
    try {
      const local = baseState ?? await loadState();
      const records: Record<string, ModuleRecord[]> = {};
      let dashboard: CustomerPortalDashboard | Record<string, unknown> | null = null;

      if (user.role === 'customer') {
        const results = await Promise.all([
          apiGet<CustomerPortalDashboard>('customer-portal/dashboard'),
          apiGet<ApiList>('customer-portal/invoices'),
          apiGet<ApiList>('customer-portal/service-tickets'),
          apiGet<ApiLedger>('customer-portal/ledger'),
          apiGet<ApiList>('customer-portal/machines'),
          apiGet<ApiList>('customer-portal/agreements'),
          apiGet<ApiList>('notifications'),
        ]);
        dashboard = results[0];
        records.invoices = (results[1].items ?? []).map((row, index) => apiRowToRecord('invoices', row, index));
        records['service-tickets'] = (results[2].items ?? []).map((row, index) => apiRowToRecord('service-tickets', row, index));
        records['customer-ledger'] = (results[3].items ?? []).map((row, index) => apiRowToRecord('customer-ledger', row, index));
        records['customer-machines'] = (results[4].items ?? []).map((row, index) => apiRowToRecord('customer-machines', row, index));
        records['agreements-emi'] = (results[5].items ?? []).map((row, index) => apiRowToRecord('agreements-emi', row, index));
        records.notifications = (results[6].items ?? []).map((row, index) => apiRowToRecord('notifications', row, index));
        const next = { ...local, records: { ...local.records, ...records }, notifications: apiNotifications(results[6]) };
        setRemoteDashboard(dashboard);
        await persist(next);
        return;
      }

      const requests: Promise<{ moduleKey: string; payload: ApiList } | null>[] = (REMOTE_LISTS_BY_ROLE[user.role] ?? []).map(async ([moduleKey, endpoint]) => {
        try { return { moduleKey, payload: await apiGet<ApiList>(endpoint) }; } catch { return null; }
      });
      const [dashboardResult, notificationResult, attendanceResult, attendanceSummaryResult, ...listResults] = await Promise.all([
        apiGet<Record<string, unknown>>('business-management/dashboard').catch(() => apiGet<Record<string, unknown>>('dashboard')),
        apiGet<ApiList>('notifications').catch(() => ({ items: [], unread: 0 })),
        apiGet<{ attendance?: Record<string, unknown> | null }>('operations/attendance/today').catch(() => ({ attendance: null })),
        apiGet<Record<string, unknown>>('operations/attendance/summary').catch(() => ({})),
        ...requests,
      ]);
      dashboard = { ...dashboardResult, attendance_summary: attendanceSummaryResult };
      for (const result of listResults) {
        if (!result) continue;
        records[result.moduleKey] = (result.payload.items ?? []).map((row, index) => apiRowToRecord(result.moduleKey, row, index));
      }
      records.notifications = (notificationResult.items ?? []).map((row, index) => apiRowToRecord('notifications', row, index));
      if (attendanceResult.attendance) records['attendance-location'] = [apiRowToRecord('attendance-location', attendanceResult.attendance, 0)];
      const next = { ...local, records: { ...local.records, ...records }, notifications: apiNotifications(notificationResult) };
      setRemoteDashboard(dashboard);
      await persist(next);
    } finally {
      setIsRefreshing(false);
    }
  }, [persist]);

  useEffect(() => {
    (async () => {
      await removeLegacyAppData();
      const [owner, user, data] = await Promise.all([hasOwner(), getSessionUser(), loadState()]);
      setOwnerExists(owner);
      setCurrentUser(user);
      setState(data);
      if (user && DATA_MODE === 'remote') await loadRemoteDataForUser(user, data);
      setReady(true);
    })().catch(() => setReady(true));
  }, [loadRemoteDataForUser]);

  const setupOwner = useCallback(async (input: { name: string; email: string; phone: string; password: string }) => {
    const user = await createOwner(input);
    setOwnerExists(true);
    setCurrentUser(user);
  }, []);

  const signIn = useCallback(async (identity: string, password: string) => {
    const user = await login(identity, password);
    setCurrentUser(user);
    if (DATA_MODE === 'remote') await loadRemoteDataForUser(user);
  }, [loadRemoteDataForUser]);

  const signOut = useCallback(async () => {
    await logout();
    setCurrentUser(null);
    setRemoteDashboard(null);
  }, []);

  const refreshRemoteData = useCallback(async () => {
    if (DATA_MODE === 'remote' && currentUser) await loadRemoteDataForUser(currentUser);
  }, [currentUser, loadRemoteDataForUser]);

  const getRecords = useCallback((key: string) => {
    if (DATA_MODE !== 'remote' && EMPLOYEE_MODULE_KEYS.has(key)) return employeeModuleRecords(key);
    return state?.records[key] ?? [];
  }, [state]);

  const addRecord = useCallback(async (moduleKey: string, values: Record<string, string | number>) => {
    if (!state) throw new Error('App data is not ready.');
    if (!currentUser) throw new Error('A signed-in user is required.');
    const module = MODULE_MAP[moduleKey];
    if (!module) throw new Error(`Unknown module: ${moduleKey}`);
    if (!module.roles.includes(currentUser.role)) throw new Error(`Permission denied: ${module.permission}`);
    if (!module.createRoles.includes(currentUser.role)) throw new Error(`Your role has view-only access to ${module.title}.`);
    if (module.fields.length === 0) throw new Error(`Developer configuration error: ${module.title} has no explicit form schema.`);
    if (values.status !== undefined && !module.statusOptions.includes(String(values.status))) throw new Error(`Invalid status for ${module.title}.`);

    if (DATA_MODE === 'remote') {
      if (!REMOTE_CREATABLE_MODULES.has(moduleKey)) throw new Error(`${module.title} is view-only in the current mobile release. Use the authorized cPanel ERP form for posting.`);
      const endpoint = currentUser.role === 'customer' && moduleKey === 'service-tickets' ? 'customer-portal/service-tickets' : module.apiEndpoint;
      await apiPost(endpoint, currentUser.role === 'customer' ? customerPayload(moduleKey, values) : staffPayload(moduleKey, values), `${moduleKey}-${Date.now()}-${currentUser.id}`);
      await loadRemoteDataForUser(currentUser);
      return;
    }

    const titleKeys = ['title', 'companyName', 'customer', 'customerName', 'supplierName', 'supplier', 'productName', 'employeeId', 'name', 'reference', 'reportType', 'documentTitle'];
    const title = String(titleKeys.map(key => values[key]).find(Boolean) || module.title);
    const reference = String(values.reference || values.customerId || values.supplierCode || values.employeeId || values.invoice || values.lcNumber || values.cardNumber || '');
    const amountRaw = values.amount || values.piValue || values.totalAmount || values.purchaseValue || values.claimAmount || values.cashPrice;
    const now = new Date().toISOString();
    const record: ModuleRecord = {
      id: `${moduleKey}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      moduleKey,
      title,
      reference,
      status: String(values.status || module.statusOptions[0] || 'draft'),
      amount: amountRaw === '' || amountRaw === undefined ? undefined : Number(amountRaw),
      date: String(values.date || values.paymentDate || values.invoiceDate || values.expenseDate || values.openingDate || values.claimDate || now.slice(0, 10)),
      notes: String(values.notes || ''),
      createdAt: now,
      updatedAt: now,
      values,
      apiEndpoint: module.apiEndpoint,
      mutationKey: module.mutationKey,
      auditAction: module.auditAction,
    };
    const audit = { id: `audit-${record.id}`, action: module.auditAction, moduleKey, recordId: record.id, actorId: currentUser.id, actorName: currentUser.name, createdAt: now, details: `${module.screenComponent} submitted ${module.apiEndpoint}` };
    const notification = { id: `notice-${record.id}`, title: `${module.title} saved`, body: `${record.title} was created by ${currentUser.name}.`, moduleKey, recordId: record.id, status: 'unread' as const, priority: moduleKey === 'notifications' ? 'important' as const : 'normal' as const, createdAt: now };
    await persist({ ...state, records: { ...state.records, [moduleKey]: [record, ...(state.records[moduleKey] ?? [])] }, auditLog: [audit, ...(state.auditLog ?? [])].slice(0, 500), notifications: [notification, ...(state.notifications ?? [])].slice(0, 500) });
  }, [state, currentUser, persist, loadRemoteDataForUser]);

  const deleteRecord = useCallback(async (moduleKey: string, id: string) => {
    if (DATA_MODE === 'remote') throw new Error('Remote records must be archived or deleted from the authorized ERP module.');
    if (!state || EMPLOYEE_MODULE_KEYS.has(moduleKey)) return;
    await persist({ ...state, records: { ...state.records, [moduleKey]: (state.records[moduleKey] ?? []).filter(record => record.id !== id) } });
  }, [state, persist]);

  const resetBusinessData = useCallback(async () => {
    if (DATA_MODE === 'remote') throw new Error('Remote production data cannot be reset from the mobile app.');
    setState(await resetState());
  }, []);

  const punchAttendance = useCallback(async (action: AttendanceAction, location: AttendanceLocation): Promise<AttendanceRecord> => {
    if (attendanceMutationLock.current) throw new Error('Attendance submission is already processing. Please wait.');
    attendanceMutationLock.current = true;
    try {
      if (!state || !currentUser) throw new Error('A signed-in employee is required for attendance.');
      if (currentUser.role === 'customer') throw new Error('Customer users do not use employee attendance.');
      const now = new Date();
      const nowIso = now.toISOString();
      const attendanceDate = localDateKey(now);
      const existingIndex = state.attendance.findIndex(item => item.employeeId === currentUser.id && item.attendanceDate === attendanceDate);
      const existing = existingIndex >= 0 ? state.attendance[existingIndex] : undefined;
      assertAttendancePunchAllowed(existing, action);

      let record: AttendanceRecord;
      if (action === 'check_in') {
        record = { id: `attendance-${currentUser.id}-${attendanceDate}`, employeeId: currentUser.id, employeeCode: currentUser.employeeCode, employeeName: currentUser.name, attendanceDate, checkInAt: nowIso, checkInLocation: location, status: 'checked_in', checkInIdempotencyKey: attendanceIdempotencyKey(currentUser.id, attendanceDate, 'check_in'), syncStatus: DATA_MODE === 'remote' ? 'pending' : 'local_only', createdAt: nowIso, updatedAt: nowIso };
      } else {
        record = { ...existing!, checkOutAt: nowIso, checkOutLocation: location, status: 'checked_out', checkOutIdempotencyKey: attendanceIdempotencyKey(currentUser.id, attendanceDate, 'check_out'), syncStatus: DATA_MODE === 'remote' ? 'pending' : existing!.syncStatus, updatedAt: nowIso };
      }

      const attendance = [...state.attendance];
      if (existingIndex >= 0) attendance[existingIndex] = record; else attendance.unshift(record);
      const existingSummary = (state.records['attendance-location'] ?? []).findIndex(item => item.reference === `${currentUser.id}:${attendanceDate}`);
      const summary: ModuleRecord = { id: `attendance-summary-${currentUser.id}-${attendanceDate}`, moduleKey: 'attendance-location', title: currentUser.name, reference: `${currentUser.id}:${attendanceDate}`, status: record.status, date: attendanceDate, notes: `GPS verified attendance • ${record.employeeCode}`, createdAt: record.createdAt, updatedAt: record.updatedAt, values: { employeeCode: record.employeeCode, checkInAt: record.checkInAt, checkOutAt: record.checkOutAt ?? '', checkInLatitude: record.checkInLocation.latitude, checkInLongitude: record.checkInLocation.longitude, checkOutLatitude: record.checkOutLocation?.latitude ?? '', checkOutLongitude: record.checkOutLocation?.longitude ?? '' } };
      const summaries = [...(state.records['attendance-location'] ?? [])];
      if (existingSummary >= 0) summaries[existingSummary] = summary; else summaries.unshift(summary);
      const audit = { id: `audit-${record.id}-${action}`, action: action === 'check_in' ? 'ATTENDANCE_CHECK_IN' : 'ATTENDANCE_CHECK_OUT', moduleKey: 'attendance-location', recordId: record.id, actorId: currentUser.id, actorName: currentUser.name, createdAt: nowIso, details: `GPS ${action} captured with duplicate-protected idempotency key.` };
      const notification = { id: `notice-${record.id}-${action}`, title: action === 'check_in' ? 'Attendance check-in recorded' : 'Attendance check-out recorded', body: `${record.employeeName} • ${attendanceDate}`, moduleKey: 'attendance-location', recordId: record.id, status: 'unread' as const, priority: 'normal' as const, createdAt: nowIso };
      let next: PersistedState = { ...state, attendance, records: { ...state.records, 'attendance-location': summaries }, auditLog: [audit, ...(state.auditLog ?? [])].slice(0, 500), notifications: [notification, ...(state.notifications ?? [])].slice(0, 500) };
      await persist(next);

      if (DATA_MODE === 'remote') {
        try {
          await syncAttendancePunch(record, action);
          record = { ...record, syncStatus: 'synced', updatedAt: new Date().toISOString() };
          next = { ...next, attendance: next.attendance.map(item => item.id === record.id ? record : item) };
          await persist(next);
          await loadRemoteDataForUser(currentUser, next);
        } catch (error) {
          throw error instanceof Error ? error : new Error('Attendance could not be synchronized with ERP.');
        }
      }
      return record;
    } finally {
      attendanceMutationLock.current = false;
    }
  }, [state, currentUser, persist, loadRemoteDataForUser]);

  const value = useMemo(() => ({ ready, ownerExists, currentUser, state, remoteDashboard, isRefreshing, setupOwner, signIn, signOut, refreshRemoteData, getRecords, addRecord, deleteRecord, resetBusinessData, punchAttendance }), [ready, ownerExists, currentUser, state, remoteDashboard, isRefreshing, setupOwner, signIn, signOut, refreshRemoteData, getRecords, addRecord, deleteRecord, resetBusinessData, punchAttendance]);
  return <Context.Provider value={value}>{children}</Context.Provider>;
}

export function useAppData() {
  const value = useContext(Context);
  if (!value) throw new Error('useAppData must be used inside AppDataProvider');
  return value;
}
