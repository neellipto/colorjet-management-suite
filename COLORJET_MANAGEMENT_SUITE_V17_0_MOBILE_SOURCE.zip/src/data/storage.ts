import AsyncStorage from '@react-native-async-storage/async-storage';
import type { PersistedState } from '@/src/types/domain';
import { createCleanState, DATA_SCHEMA_VERSION } from './seed';

const STATE_KEY = '@colorjet/erp/v14/state';

function migrateState(input: Partial<PersistedState> & { schemaVersion?: number }): PersistedState {
  const clean = createCleanState();
  if (input.schemaVersion === 14 || input.schemaVersion === 15 || input.schemaVersion === DATA_SCHEMA_VERSION) {
    return {
      ...clean,
      ...input,
      schemaVersion: DATA_SCHEMA_VERSION,
      company: { ...clean.company, ...(input.company ?? {}) },
      records: input.records ?? {},
      attendance: input.attendance ?? [],
      auditLog: input.auditLog ?? [],
      notifications: input.notifications ?? [],
      migratedAt: new Date().toISOString(),
    };
  }
  return clean;
}

export async function loadState(): Promise<PersistedState> {
  const raw = await AsyncStorage.getItem(STATE_KEY);
  if (!raw) return createCleanState();
  try {
    return migrateState(JSON.parse(raw) as Partial<PersistedState> & { schemaVersion?: number });
  } catch { return createCleanState(); }
}
export async function saveState(state: PersistedState): Promise<void> {
  await AsyncStorage.setItem(STATE_KEY, JSON.stringify(state));
}
export async function resetState(): Promise<PersistedState> {
  const clean = createCleanState();
  await saveState(clean);
  return clean;
}
