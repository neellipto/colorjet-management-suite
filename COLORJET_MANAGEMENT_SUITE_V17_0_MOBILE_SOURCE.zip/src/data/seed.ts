import type { PersistedState } from '@/src/types/domain';
export const DATA_SCHEMA_VERSION = 16;
export const createCleanState = (): PersistedState => ({
  schemaVersion: DATA_SCHEMA_VERSION,
  company: {
    name: 'COLORJET Bangladesh',
    tagline: 'Quality • Commitment • Service',
    hotline: '+8809677610610',
    whatsapp: '+8801954100710',
    email: 'info@colorjet.com.bd',
    website: 'www.colorjetbd.com'
  },
  records: {},
  attendance: [],
  auditLog: [],
  notifications: [],
  migratedAt: new Date().toISOString()
});
