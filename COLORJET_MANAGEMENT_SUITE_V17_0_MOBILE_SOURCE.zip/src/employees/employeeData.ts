import type { ImageSourcePropType } from 'react-native';

export interface EmployeeDirectoryRecord {
  code: string;
  name: string;
  designation: string;
  department: string;
  phone: string;
  email: string;
  bloodGroup: string;
  role: string;
  status: 'ACTIVE' | 'INACTIVE';
  verificationStatus: 'VERIFIED' | 'PENDING';
  company: string;
  photo: ImageSourcePropType;
  sourceFile: string;
}

/**
 * Employee names and identity data were extracted from the uploaded verified employee packages.
 * Images are copied byte-for-byte from the uploaded original_photos folder. No crop, recolor,
 * retouch, replacement or regeneration is performed in this app package.
 */
export const EMPLOYEES: readonly EmployeeDirectoryRecord[] = [
  { code:'CJ-MD-001', name:'Md Aktaruzzaman', designation:'Founder & Managing Director', department:'Management', phone:'01954100710', email:'admin@colorjetbd.com', bloodGroup:'AB+', role:'OWNER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/19_19.png'), sourceFile:'19_19.png' },
  { code:'CJ-MGMT-002', name:'Al-amin', designation:'Managing Partner & Co-Founder', department:'Management', phone:'01748406996', email:'alamin@colorjetbd.com', bloodGroup:'A+', role:'ADMIN', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/18_18.png'), sourceFile:'18_18.png' },
  { code:'CJ-MGMT-003', name:'Md. Abu Rasel', designation:'General Manager', department:'Management', phone:'01958253980', email:'abu121rashel@gmail.com', bloodGroup:'A+', role:'MANAGER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/01_abu_rasel.png'), sourceFile:'01_abu_rasel.png' },
  { code:'CJ-MGMT-004', name:'Sheikh Md. Alim Hosen', designation:'Manager', department:'Management', phone:'01958253981', email:'alim@colorjetbd.com', bloodGroup:'A+', role:'MANAGER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/02_alim.png'), sourceFile:'02_alim.png' },
  { code:'CJ-ACC-005', name:'Mohammad Rasel', designation:'Accounts Manager', department:'Accounts', phone:'01815512906', email:'mdr152152@gmail.com', bloodGroup:'O+', role:'ACCOUNTS', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/03_accounts_rasel.png'), sourceFile:'03_accounts_rasel.png' },
  { code:'CJ-MGMT-006', name:'Atiq Faisal Ani', designation:'Operation & Service Control Head', department:'Management', phone:'01784498722', email:'afani0406@gmail.com', bloodGroup:'O+', role:'SERVICE_MANAGER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/04_atiq.png'), sourceFile:'04_atiq.png' },
  { code:'CJ-TECH-007', name:'Zahed Islam', designation:'Senior Engineer', department:'Technical', phone:'01958253983', email:'zahedislam999@gmail.com', bloodGroup:'O+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/05_zahed.png'), sourceFile:'05_zahed.png' },
  { code:'CJ-TECH-008', name:'Md. Sadakatul Bari', designation:'Senior Engineer', department:'Technical', phone:'01958253984', email:'sadakatulbari120@gmail.com', bloodGroup:'AB+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/06_sadik.png'), sourceFile:'06_sadik.png' },
  { code:'CJ-TECH-009', name:'Md. Tamim Alam', designation:'Senior Engineer', department:'Technical', phone:'01717511213', email:'zxtammim@gmail.com', bloodGroup:'A+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/15_15.png'), sourceFile:'15_15.png' },
  { code:'CJ-TECH-010', name:'Md Hasan Ali', designation:'Engineer', department:'Technical', phone:'01958253986', email:'jh9635516@gmail.com', bloodGroup:'O+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/07_hasan.png'), sourceFile:'07_hasan.png' },
  { code:'CJ-TECH-011', name:'MD Asif Hossain', designation:'Engineer', department:'Technical', phone:'01615755155', email:'asifhossain6886@gmail.com', bloodGroup:'A+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/08_asif.png'), sourceFile:'08_asif.png' },
  { code:'CJ-TECH-012', name:'MD Hasibul Islam Turjo', designation:'Junior Engineer', department:'Technical', phone:'01323377862', email:'hasibulislamturjo23@gmail.com', bloodGroup:'B+', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/09_turjo.png'), sourceFile:'09_turjo.png' },
  { code:'CJ-MGMT-013', name:'Rana Ahammed', designation:'Commercial Executive', department:'Management', phone:'01958253982', email:'rana.ahammed.ac@gmail.com', bloodGroup:'B+', role:'OFFICE_STAFF', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/17_17.png'), sourceFile:'17_17.png' },
  { code:'CJ-TECH-014', name:'Sayeduzzaman Shohel', designation:'Junior Engineer', department:'Technical', phone:'01914175005', email:'toriqulislam.tk@gmail.com', bloodGroup:'A-', role:'ENGINEER', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/10_shohel.png'), sourceFile:'10_shohel.png' },
  { code:'CJ-TR-015', name:'Shamim Sana', designation:'Driver', department:'Transport', phone:'01715962285', email:'', bloodGroup:'O+', role:'OFFICE_STAFF', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/11_shamim.png'), sourceFile:'11_shamim.png' },
  { code:'CJ-MGMT-016', name:'Md Hasib Mia', designation:'Sales Executive', department:'Sales', phone:'01731416747', email:'', bloodGroup:'B+', role:'SALES', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/16_16.png'), sourceFile:'16_16.png' },
  { code:'CJ-MGMT-017', name:'Muktar Hamid', designation:'Sales & Marketing Executive', department:'Marketing', phone:'01958253988', email:'muktarhamid32@gmail.com', bloodGroup:'A+', role:'SALES', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/12_muktar.png'), sourceFile:'12_muktar.png' },
  { code:'CJ-MGMT-018', name:'Sheikh Md Arif Hossain', designation:'Sales Executive', department:'Sales', phone:'01743856481', email:'', bloodGroup:'A+', role:'SALES', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/13_arif.png'), sourceFile:'13_arif.png' },
  { code:'CJ-TR-019', name:'Abdur Rahman', designation:'Driver', department:'Transport', phone:'01795062998', email:'', bloodGroup:'', role:'OFFICE_STAFF', status:'ACTIVE', verificationStatus:'VERIFIED', company:'COLORJET Bangladesh', photo:require('../../assets/employees/original/14_rahman.png'), sourceFile:'14_rahman.png' },
] as const;
