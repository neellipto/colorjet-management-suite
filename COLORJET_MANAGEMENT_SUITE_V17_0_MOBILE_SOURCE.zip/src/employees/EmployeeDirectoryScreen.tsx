import React, { useMemo, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Stack, useRouter } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { EMPLOYEES } from './employeeData';
import { colors, radius, spacing, typography } from '@/src/theme/tokens';

type Mode = 'directory' | 'verification' | 'id_cards';

const modeText: Record<Mode, { title: string; subtitle: string; placeholder: string }> = {
  directory: { title: 'Employee Directory', subtitle: 'Verified employee profiles and departments', placeholder: 'Search name, ID, department or role' },
  verification: { title: 'Employee Verification', subtitle: 'Verify identity by employee ID, name or phone', placeholder: 'Enter employee ID, name or phone' },
  id_cards: { title: 'Employee ID Cards', subtitle: 'Digital employee identity card records', placeholder: 'Search employee ID card' },
};

export function EmployeeDirectoryScreen({ mode }: { mode: Mode }) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const text = modeText[mode];
  const employees = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return EMPLOYEES;
    return EMPLOYEES.filter((employee) => [employee.code, employee.name, employee.designation, employee.department, employee.phone, employee.role]
      .join(' ').toLowerCase().includes(normalized));
  }, [query]);

  return <Screen>
    <Stack.Screen options={{ headerShown: false }} />
    <View style={styles.header}>
      <Pressable onPress={() => router.back()} style={styles.back}><Ionicons name="arrow-back" size={22} color={colors.primary}/></Pressable>
      <View style={styles.heading}><Text style={styles.title}>{text.title}</Text><Text style={styles.subtitle}>{text.subtitle}</Text></View>
    </View>
    <TextInput value={query} onChangeText={setQuery} placeholder={text.placeholder} placeholderTextColor={colors.mutedForeground} style={styles.search}/>
    <View style={styles.summary}><Text style={styles.summaryValue}>{employees.length}</Text><Text style={styles.summaryLabel}>Verified employee records</Text></View>
    {employees.map((employee) => <Card key={employee.code} style={mode === 'id_cards' ? styles.idCard : styles.employeeCard}>
      <View style={styles.employeeTop}>
        <Image source={employee.photo} style={styles.photo} resizeMode="cover" />
        <View style={styles.employeeInfo}>
          <Text style={styles.name}>{employee.name}</Text>
          <Text style={styles.designation}>{employee.designation}</Text>
          <Text style={styles.code}>{employee.code} • {employee.department}</Text>
        </View>
        <View style={styles.verified}><Ionicons name="checkmark-circle" size={16} color={colors.success}/><Text style={styles.verifiedText}>Verified</Text></View>
      </View>
      <View style={styles.divider}/>
      <View style={styles.metaRow}><Ionicons name="call-outline" size={15} color={colors.primary}/><Text style={styles.meta}>{employee.phone || 'Not provided'}</Text></View>
      {employee.email ? <View style={styles.metaRow}><Ionicons name="mail-outline" size={15} color={colors.primary}/><Text style={styles.meta}>{employee.email}</Text></View> : null}
      <View style={styles.metaRow}><Ionicons name="briefcase-outline" size={15} color={colors.primary}/><Text style={styles.meta}>{employee.role} • {employee.status}</Text></View>
      {mode === 'id_cards' ? <View style={styles.cardFooter}><Text style={styles.company}>COLORJET Bangladesh</Text><Text style={styles.tagline}>Quality • Commitment • Service</Text></View> : null}
    </Card>)}
  </Screen>;
}

const styles = StyleSheet.create({
  header:{minHeight:68,flexDirection:'row',alignItems:'center',gap:spacing.md},back:{width:40,height:40,borderRadius:radius.md,backgroundColor:colors.card,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:colors.border},heading:{flex:1},title:{fontFamily:typography.bold,fontSize:19,color:colors.text},subtitle:{fontFamily:typography.regular,fontSize:10,color:colors.mutedForeground,marginTop:2},
  search:{height:48,borderRadius:radius.md,borderWidth:1,borderColor:colors.border,backgroundColor:colors.card,paddingHorizontal:spacing.lg,fontFamily:typography.regular,color:colors.text,marginTop:spacing.sm},
  summary:{backgroundColor:colors.primary,borderRadius:radius.lg,padding:spacing.lg,marginTop:spacing.lg,marginBottom:spacing.lg},summaryValue:{fontFamily:typography.bold,fontSize:28,color:colors.primaryForeground},summaryLabel:{fontFamily:typography.medium,fontSize:11,color:colors.orangeLight,marginTop:2},
  employeeCard:{marginBottom:spacing.md},idCard:{marginBottom:spacing.md,borderColor:colors.primary},employeeTop:{flexDirection:'row',alignItems:'center',gap:spacing.md},photo:{width:62,height:62,borderRadius:radius.lg,backgroundColor:colors.muted},employeeInfo:{flex:1},name:{fontFamily:typography.bold,fontSize:14,color:colors.text},designation:{fontFamily:typography.medium,fontSize:10,color:colors.secondary,marginTop:3},code:{fontFamily:typography.regular,fontSize:9,color:colors.mutedForeground,marginTop:4},verified:{alignItems:'center',gap:2},verifiedText:{fontFamily:typography.semibold,fontSize:8,color:colors.success},divider:{height:1,backgroundColor:colors.border,marginVertical:spacing.md},metaRow:{flexDirection:'row',alignItems:'center',gap:spacing.sm,marginBottom:7},meta:{fontFamily:typography.regular,fontSize:10,color:colors.text,flex:1},cardFooter:{marginTop:spacing.sm,borderRadius:radius.md,backgroundColor:colors.navyLight,padding:spacing.md},company:{fontFamily:typography.bold,fontSize:11,color:colors.primary},tagline:{fontFamily:typography.medium,fontSize:8,color:colors.secondary,marginTop:2},
});
