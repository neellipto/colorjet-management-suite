# COLORJET Management Suite V17.0 Mobile Source

- Version: 1.7.0
- Android package: `com.colorjetbd.managementsuite`
- versionCode: 1700
- Production mode: cPanel API token authentication
- Customer-linked dashboard and scoped records
- Attendance %, notifications and role access integration

## Start

```bash
cp .env.example .env
npm ci
npm run verify
npx expo start
```

`.env`-এ production API base URL দিন। কোনো private credential source file-এ লিখবেন না। বিস্তারিত `docs/MOBILE_BUILD_AND_QA_V17_BN.md` দেখুন।
