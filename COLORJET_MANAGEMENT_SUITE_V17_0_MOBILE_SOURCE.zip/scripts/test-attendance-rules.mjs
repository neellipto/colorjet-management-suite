import assert from 'node:assert/strict';
import { assertAttendancePunchAllowed } from '../src/attendance/attendanceRules.ts';

const base = {
  id:'attendance-user-2026-07-13', employeeId:'user', employeeCode:'CJ-001', employeeName:'User',
  attendanceDate:'2026-07-13', checkInAt:'2026-07-13T08:00:00.000Z',
  checkInLocation:{latitude:23.8,longitude:90.4,accuracyM:12,altitudeM:null,heading:null,speedMps:null,capturedAt:'2026-07-13T08:00:00.000Z',mocked:false},
  status:'checked_in', checkInIdempotencyKey:'att-check-in', syncStatus:'local_only',
  createdAt:'2026-07-13T08:00:00.000Z', updatedAt:'2026-07-13T08:00:00.000Z'
};

assert.doesNotThrow(()=>assertAttendancePunchAllowed(undefined,'check_in'));
assert.throws(()=>assertAttendancePunchAllowed(base,'check_in'),/Duplicate attendance/);
assert.throws(()=>assertAttendancePunchAllowed(undefined,'check_out'),/Check-in is required/);
assert.doesNotThrow(()=>assertAttendancePunchAllowed(base,'check_out'));
assert.throws(()=>assertAttendancePunchAllowed({...base,checkOutAt:'2026-07-13T17:00:00.000Z'},'check_out'),/Duplicate attendance/);
console.log('Attendance rule tests passed: 5/5');
