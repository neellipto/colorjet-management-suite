import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const root=process.cwd();const manifest=JSON.parse(fs.readFileSync(path.join(root,'ui-lock.manifest.json'),'utf8'));let failed=false;
for(const [file,expected] of Object.entries(manifest.files)){const p=path.join(root,file);if(!fs.existsSync(p)){console.error(`UI LOCK FAIL: missing ${file}`);failed=true;continue}const actual=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');if(actual!==expected){console.error(`UI LOCK FAIL: modified ${file}`);failed=true}}
if(failed)process.exit(1);console.log(`UI lock verified: ${Object.keys(manifest.files).length} protected files (${manifest.version}).`);
