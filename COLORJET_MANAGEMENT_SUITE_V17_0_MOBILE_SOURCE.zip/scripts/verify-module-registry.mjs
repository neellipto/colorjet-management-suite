import fs from 'node:fs';
const text=fs.readFileSync('src/core/moduleRegistry.ts','utf8');
const keys=[...text.matchAll(/key:'([^']+)'/g)].map(m=>m[1]);
const dup=keys.filter((v,i)=>keys.indexOf(v)!==i);
if(dup.length){console.error('Duplicate module keys:',[...new Set(dup)]);process.exit(1)}
if(keys.length<35){console.error(`Expected at least 35 modules; found ${keys.length}`);process.exit(1)}
if(/commonFields|dateRefFields|fields:\s*\[\s*\]/.test(text)){console.error('Generic or empty form schema is not allowed.');process.exit(1)}
const required=['formId','routeName','screenComponent','apiEndpoint','mutationKey','permission','auditAction'];
for(const item of required){if(!text.includes(item)){console.error(`Missing module metadata: ${item}`);process.exit(1)}}
const endpoints=[...text.matchAll(/apiEndpoint:'([^']+)'/g)].map(m=>m[1]);
const endpointDup=endpoints.filter((v,i)=>endpoints.indexOf(v)!==i);
if(endpointDup.length){console.error('Duplicate API endpoints:',[...new Set(endpointDup)]);process.exit(1)}
const routeDup=[...text.matchAll(/routeName:'([^']+)'/g)].map(m=>m[1]).filter((v,i,a)=>a.indexOf(v)!==i);
if(routeDup.length){console.error('Duplicate create routes:',[...new Set(routeDup)]);process.exit(1)}
console.log(`Module registry verified: ${keys.length} unique modules, ${endpoints.length} explicit API endpoints, no generic fallback forms.`);
