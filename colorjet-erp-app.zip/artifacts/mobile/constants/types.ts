export type UserRole =
  | 'admin'
  | 'manager'
  | 'engineer'
  | 'service_control'
  | 'marketing'
  | 'sales'
  | 'accounts'
  | 'store'
  | 'customer';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  role: UserRole;
  roleTitle?: string;
  employeeCode?: string;
  department?: string;
  isActive: boolean;
  lastLogin?: string;
  permissions?: string[];
}

export interface Customer {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address: string;
  district: string;
  customerType: 'Dealer' | 'End User' | 'Corporate';
  creditLimit: number;
  totalDue: number;
  totalPaid: number;
  createdAt: string;
  assignedEngineerId?: string;
  assignedMarketingId?: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  icon?: string;
  image?: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  categoryId: string;
  categoryName: string;
  productType: 'machine' | 'ink' | 'spare' | 'consumable' | 'material';
  brand: string;
  model: string;
  uom: string;
  costPrice: number;
  salePrice: number;
  currentStock: number;
  minStockQty: number;
  isActive: boolean;
}

export interface InvoiceLine {
  id: string;
  productId: string;
  productName: string;
  description?: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
}

export interface Invoice {
  id: string;
  invoiceNo: string;
  customerId: string;
  customerName: string;
  invoiceDate: string;
  dueDate: string;
  status: 'draft' | 'posted' | 'paid' | 'partial';
  lines: InvoiceLine[];
  totalAmount: number;
  totalPaid: number;
  totalDue: number;
  createdBy: string;
  notes?: string;
}

export interface Payment {
  id: string;
  paymentNo: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  paymentDate: string;
  amount: number;
  method: 'Cash' | 'Bank Transfer' | 'bKash' | 'Nagad' | 'Card' | 'Cheque';
  reference?: string;
  createdBy: string;
}

export type TicketStatus =
  | 'pending'
  | 'assigned'
  | 'accepted'
  | 'on_the_way'
  | 'in_progress'
  | 'waiting_parts'
  | 'pending_customer'
  | 'completed'
  | 'revisit'
  | 'cancelled';

export type WarrantyStatus = 'in_warranty' | 'out_warranty' | 'amc';

export interface ServicePart {
  productId: string;
  productName: string;
  qty: number;
  billing?: 'warranty' | 'free' | 'chargeable';
  unitPrice?: number;
  note?: string;
}

export interface ServicePhoto {
  id: string;
  uri: string;
  type: 'before' | 'problem' | 'parts' | 'serial' | 'after' | 'other';
  caption?: string;
  createdAt: string;
}

export interface ServiceSignature {
  customerName: string;
  customerPhone?: string;
  signatureData?: string;
  rating?: number;
  comment?: string;
  confirmed: boolean;
  signedAt: string;
}

export interface ServiceReport {
  problemFound: string;
  workDone: string;
  pendingIssue?: string;
  revisitRequired: boolean;
  submittedAt: string;
  submittedById: string;
  submittedByName: string;
}

export interface ServiceTicket {
  id: string;
  ticketNo: string;
  customerId: string;
  customerName: string;
  companyName?: string;
  customerPhone?: string;
  customerWhatsapp?: string;
  customerAddress: string;
  district?: string;
  area?: string;
  machineModel?: string;
  machineSerial?: string;
  installationDate?: string;
  warrantyStatus?: WarrantyStatus;
  chargeable?: boolean;
  problemCategory?: string;
  title: string;
  description: string;
  priority: 'low' | 'normal' | 'high' | 'emergency';
  status: TicketStatus;
  assignedEngineerId: string;
  assignedEngineerName: string;
  createdAt: string;
  plannedDate: string;
  scheduledTime?: string;
  completedDate?: string;
  workNotes?: string;
  usedParts?: ServicePart[];
  photos?: ServicePhoto[];
  signature?: ServiceSignature;
  report?: ServiceReport;
  revisitRequired?: boolean;
  travelStartAt?: string;
  workStartAt?: string;
  workEndAt?: string;
  isPaused?: boolean;
  pauseStartedAt?: string;
  pausedMs?: number;
  totalTravelMs?: number;
  totalWorkMs?: number;
}

export interface ServiceLog {
  id: string;
  ticketId: string;
  ticketNo: string;
  userId: string;
  userName: string;
  action: string;
  fromStatus?: string;
  toStatus?: string;
  note?: string;
  createdAt: string;
}

export interface ScheduleEntry {
  id: string;
  engineerId: string;
  engineerName: string;
  ticketId?: string;
  ticketNo?: string;
  customerName: string;
  area: string;
  date: string;
  time: string;
  priority: 'low' | 'normal' | 'high' | 'emergency';
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled';
  note?: string;
}

export type EngineerAvailability = 'available' | 'busy' | 'on_job' | 'leave' | 'offline';

export interface EngineerProfile {
  id: string;
  userId: string;
  name: string;
  phone: string;
  area: string;
  photo?: string;
  roleTitle: string;
  skills: string[];
  availability: EngineerAvailability;
  completedJobs: number;
  lateJobs: number;
  rating: number;
  firstTimeFixPct: number;
  travelKm: number;
  revenueContribution: number;
  permissions: Record<string, boolean>;
}

export interface MarketingTask {
  id: string;
  taskNo: string;
  type: 'visit' | 'collection' | 'delivery_support';
  customerId: string;
  customerName: string;
  assignedMarketingId: string;
  targetDate: string;
  status: 'pending' | 'in_progress' | 'done';
  purpose: string;
  collectedAmount?: number;
  paymentMethod?: string;
  notes?: string;
  visitStartTime?: string;
  visitEndTime?: string;
}

export interface StockMove {
  id: string;
  productId: string;
  productName: string;
  qty: number;
  moveType: 'purchase_in' | 'sale_out' | 'service_use' | 'adjust' | 'transfer';
  moveDate: string;
  createdBy: string;
  reference?: string;
  notes?: string;
}

export interface DeliveryOrder {
  id: string;
  doNo: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  deliveryDate: string;
  deliveredById: string;
  deliveredByName: string;
  vehicleNo: string;
  receiverName: string;
  receiverPhone: string;
  status: 'pending' | 'out_for_delivery' | 'delivered';
  items: string[];
}

export interface Expense {
  id: string;
  expenseDate: string;
  category: string;
  description: string;
  amount: number;
  paidById: string;
  paidByName: string;
  paymentMethod: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'stock_warning' | 'due_warning' | 'new_ticket' | 'status_change' | 'payment' | 'job_assigned' | 'complaint';
  isRead: boolean;
  createdAt: string;
}

export interface CompanySettings {
  companyName: string;
  shortName: string;
  hotline: string;
  email: string;
  address: string;
  website: string;
  facebook: string;
  instagram: string;
  youtube: string;
  linkedin: string;
  tagline: string;
}

export interface BrandingSettings {
  themeColor: string;
  accentColor: string;
  headerGradient: boolean;
  fontScale: 'small' | 'normal' | 'large';
  buttonStyle: 'rounded' | 'square';
  appearance: 'light' | 'dark' | 'auto';
}

export interface CatalogAsset {
  id: string;
  type: 'machine_image' | 'category_image' | 'spare_image' | 'catalog_pdf' | 'employee_photo' | 'banner' | 'datasheet';
  name: string;
  uri?: string;
  note?: string;
  createdAt: string;
}

export interface OdooSettings {
  domain: string;
  database: string;
  username: string;
  apiKey: string;
  autoSync: boolean;
  syncInterval: 'hourly' | 'daily' | 'manual';
  modules: Record<string, boolean>;
  status: 'configured' | 'not_configured';
}

export interface MessagingChannel {
  enabled: boolean;
  status: 'configured' | 'not_configured';
}

export interface MessagingSettings {
  whatsapp: MessagingChannel;
  facebook: MessagingChannel;
  instagram: MessagingChannel;
  liveChat: MessagingChannel;
  email: MessagingChannel;
  sms: MessagingChannel;
  googleBusiness: MessagingChannel;
  tiktok: MessagingChannel;
}

export interface IntegrationSettings {
  odoo: OdooSettings;
  messaging: MessagingSettings;
}

export interface NotificationSettings {
  alerts: Record<string, boolean>;
  channels: Record<string, boolean>;
}

export interface DashboardStats {
  totalSalesMTD: number;
  totalCollectionMTD: number;
  totalDue: number;
  totalExpenses: number;
  openTickets: number;
  inProgressTickets: number;
  completedTicketsMTD: number;
  pendingDeliveries: number;
  lowStockItems: number;
  activeCustomers: number;
}
