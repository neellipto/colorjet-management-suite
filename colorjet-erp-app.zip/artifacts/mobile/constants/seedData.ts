import type {
  User, Customer, Product, ProductCategory, Invoice, Payment,
  ServiceTicket, ServiceLog, ScheduleEntry, EngineerProfile,
  MarketingTask, StockMove, DeliveryOrder, Expense, Notification,
  CompanySettings, BrandingSettings, CatalogAsset, IntegrationSettings, NotificationSettings,
} from './types';

// Bump this whenever the production seed changes so returning devices reset
// their locally cached data to the current seed on next launch.
export const SEED_VERSION = 2;

// Production app ships with a single administrator account and no sample data.
// Additional users, customers, products, etc. are created from within the app.
export const ADMIN_USER: User = {
  id: 'admin-001', name: 'Administrator', email: 'admin@colorjet.com', password: 'admin123', phone: '01711-000001', role: 'admin', roleTitle: 'Owner / Admin', employeeCode: 'ADM-001', department: 'Management', isActive: true,
};

export const ALL_USERS: User[] = [ADMIN_USER];

export const SEED_CUSTOMERS: Customer[] = [];

export const SEED_PRODUCTS: Product[] = [];

export const SEED_INVOICES: Invoice[] = [];

export const SEED_PAYMENTS: Payment[] = [];

export const SEED_TICKETS: ServiceTicket[] = [];

export const SEED_TASKS: MarketingTask[] = [];

export const SEED_STOCK_MOVES: StockMove[] = [];

export const SEED_DELIVERIES: DeliveryOrder[] = [];

export const SEED_EXPENSES: Expense[] = [];

export const SEED_NOTIFICATIONS: Notification[] = [];

export const SEED_CATEGORIES: ProductCategory[] = [];

export const SEED_ENGINEERS: EngineerProfile[] = [];

export const SEED_SERVICE_LOGS: ServiceLog[] = [];

export const SEED_SCHEDULE: ScheduleEntry[] = [];

export const SEED_CATALOG_ASSETS: CatalogAsset[] = [];

export const DEFAULT_COMPANY: CompanySettings = {
  companyName: 'COLORJET Bangladesh',
  shortName: 'COLORJET',
  hotline: '09666-777888',
  email: 'info@colorjet.com.bd',
  address: 'House 12, Road 4, Gulshan-1, Dhaka 1212, Bangladesh',
  website: 'www.colorjet.com.bd',
  facebook: 'facebook.com/colorjetbd',
  instagram: 'instagram.com/colorjetbd',
  youtube: 'youtube.com/@colorjetbd',
  linkedin: 'linkedin.com/company/colorjetbd',
  tagline: 'Business Management System',
};

export const DEFAULT_BRANDING: BrandingSettings = {
  themeColor: '#1A237E',
  accentColor: '#F57C00',
  headerGradient: true,
  fontScale: 'normal',
  buttonStyle: 'rounded',
  appearance: 'light',
};

export const DEFAULT_INTEGRATIONS: IntegrationSettings = {
  odoo: {
    domain: '',
    database: '',
    username: '',
    apiKey: '',
    autoSync: false,
    syncInterval: 'manual',
    modules: { sales: true, inventory: true, accounting: true, crm: false, hr: false },
    status: 'not_configured',
  },
  messaging: {
    whatsapp: { enabled: false, status: 'not_configured' },
    facebook: { enabled: false, status: 'not_configured' },
    instagram: { enabled: false, status: 'not_configured' },
    liveChat: { enabled: false, status: 'not_configured' },
    email: { enabled: true, status: 'configured' },
    sms: { enabled: false, status: 'not_configured' },
    googleBusiness: { enabled: false, status: 'not_configured' },
    tiktok: { enabled: false, status: 'not_configured' },
  },
};

export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  alerts: {
    new_ticket: true,
    status_change: true,
    job_assigned: true,
    stock_warning: true,
    due_warning: true,
    payment: true,
    complaint: true,
  },
  channels: {
    in_app: true,
    email: true,
    sms: false,
    whatsapp: false,
  },
};
