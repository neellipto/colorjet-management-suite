import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  useCreateScheduleEntry, useCreateTicket, useCreateUser,
  useGetEngineers, useGetSchedule, useGetSettings, useGetTickets, useGetUsers,
  useLogin, useUpdateEngineer, useUpdateScheduleEntry, useUpdateSettings,
  useUpdateTicket, useUpdateUser,
} from '@workspace/api-client-react';
import type {
  EngineerProfileUpdate, ScheduleEntryInput, ScheduleEntryUpdate,
  ServiceTicketInput, ServiceTicketUpdate, SettingsUpdate, UserInput, UserUpdate,
} from '@workspace/api-client-react';
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  ALL_USERS, SEED_CUSTOMERS, SEED_DELIVERIES, SEED_EXPENSES,
  SEED_INVOICES, SEED_NOTIFICATIONS, SEED_PAYMENTS,
  SEED_PRODUCTS, SEED_STOCK_MOVES, SEED_TICKETS, SEED_TASKS,
  SEED_CATEGORIES, SEED_ENGINEERS, SEED_SERVICE_LOGS, SEED_SCHEDULE, SEED_CATALOG_ASSETS,
  DEFAULT_COMPANY, DEFAULT_BRANDING, DEFAULT_INTEGRATIONS, DEFAULT_NOTIFICATION_SETTINGS,
  SEED_VERSION,
} from '@/constants/seedData';
import type {
  Customer, DeliveryOrder, Expense, Invoice, MarketingTask,
  Notification, Payment, Product, ProductCategory, ServiceTicket, ServicePart, ServicePhoto,
  ServiceSignature, ServiceReport, ServiceLog, ScheduleEntry, EngineerProfile,
  StockMove, User, TicketStatus,
  CompanySettings, BrandingSettings, CatalogAsset, IntegrationSettings, NotificationSettings,
} from '@/constants/types';

const STORAGE_KEY = 'colorjet_erp_v2';

interface AppState {
  users: User[];
  customers: Customer[];
  products: Product[];
  categories: ProductCategory[];
  invoices: Invoice[];
  payments: Payment[];
  tickets: ServiceTicket[];
  serviceLogs: ServiceLog[];
  schedule: ScheduleEntry[];
  engineers: EngineerProfile[];
  tasks: MarketingTask[];
  stockMoves: StockMove[];
  deliveries: DeliveryOrder[];
  expenses: Expense[];
  notifications: Notification[];
  catalogAssets: CatalogAsset[];
  company: CompanySettings;
  branding: BrandingSettings;
  integrations: IntegrationSettings;
  notificationSettings: NotificationSettings;
}

interface AppContextValue extends AppState {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  // Tickets / Service
  addTicket: (ticket: Omit<ServiceTicket, 'id' | 'ticketNo' | 'createdAt'>) => void;
  updateTicketStatus: (id: string, status: TicketStatus, note?: string) => void;
  assignEngineer: (ticketId: string, engineerId: string, engineerName: string) => void;
  startTravel: (ticketId: string) => void;
  startWork: (ticketId: string) => void;
  pauseWork: (ticketId: string) => void;
  resumeWork: (ticketId: string) => void;
  completeWork: (ticketId: string) => void;
  addTicketPart: (ticketId: string, part: ServicePart) => void;
  addTicketPhoto: (ticketId: string, photo: Omit<ServicePhoto, 'id' | 'createdAt'>) => void;
  saveSignature: (ticketId: string, sig: Omit<ServiceSignature, 'signedAt'>) => void;
  submitReport: (ticketId: string, report: Omit<ServiceReport, 'submittedAt'>) => void;
  // Schedule
  addScheduleEntry: (entry: Omit<ScheduleEntry, 'id'>) => void;
  updateScheduleStatus: (id: string, status: ScheduleEntry['status']) => void;
  // Engineers
  updateEngineer: (id: string, data: Partial<EngineerProfile>) => void;
  // Users
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, data: Partial<User>) => void;
  toggleUserActive: (id: string) => void;
  // Catalog / categories
  addCategory: (name: string, icon?: string) => void;
  deleteCategory: (id: string) => void;
  addCatalogAsset: (asset: Omit<CatalogAsset, 'id' | 'createdAt'>) => void;
  deleteCatalogAsset: (id: string) => void;
  // Settings
  saveCompany: (data: Partial<CompanySettings>) => void;
  saveBranding: (data: Partial<BrandingSettings>) => void;
  saveIntegrations: (data: IntegrationSettings) => void;
  saveNotificationSettings: (data: NotificationSettings) => void;
  // Finance / inventory / misc (existing)
  addInvoice: (invoice: Omit<Invoice, 'id' | 'invoiceNo'>) => void;
  addPayment: (payment: Omit<Payment, 'id' | 'paymentNo'>) => void;
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  addStockMove: (move: Omit<StockMove, 'id'>) => void;
  updateDeliveryStatus: (id: string, status: DeliveryOrder['status']) => void;
  updateTaskStatus: (id: string, status: MarketingTask['status'], data?: Partial<MarketingTask>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  unreadCount: number;
}

const AppContext = createContext<AppContextValue | null>(null);

function makeId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
}

function padNum(n: number, len = 4): string {
  return String(n).padStart(len, '0');
}

function now(): string {
  return new Date().toISOString();
}

function today(): string {
  return new Date().toISOString().split('T')[0];
}

function buildSeed(): AppState {
  return {
    users: ALL_USERS.map(u => ({ ...u })),
    customers: SEED_CUSTOMERS,
    products: SEED_PRODUCTS,
    categories: SEED_CATEGORIES,
    invoices: SEED_INVOICES,
    payments: SEED_PAYMENTS,
    tickets: SEED_TICKETS,
    serviceLogs: SEED_SERVICE_LOGS,
    schedule: SEED_SCHEDULE,
    engineers: SEED_ENGINEERS,
    tasks: SEED_TASKS,
    stockMoves: SEED_STOCK_MOVES,
    deliveries: SEED_DELIVERIES,
    expenses: SEED_EXPENSES,
    notifications: SEED_NOTIFICATIONS,
    catalogAssets: SEED_CATALOG_ASSETS,
    company: DEFAULT_COMPANY,
    branding: DEFAULT_BRANDING,
    integrations: DEFAULT_INTEGRATIONS,
    notificationSettings: DEFAULT_NOTIFICATION_SETTINGS,
  };
}

// Fixed ids that earlier builds seeded as demo/sample data. On upgrade these are
// stripped from any cached AsyncStorage state while user-created records (which
// use generated ids) are preserved. Mirrors the server-side purge in seed.ts.
const seq = (prefix: string, count: number, start = 1): string[] =>
  Array.from({ length: count }, (_, i) => `${prefix}${i + start}`);

const LEGACY_DEMO_IDS: Record<string, string[]> = {
  users: [...seq('u', 9), ...seq('e', 8, 10)],
  customers: seq('c', 8),
  products: seq('p', 12),
  categories: seq('cat', 8),
  invoices: seq('inv', 8),
  payments: seq('pay', 5),
  tickets: seq('tk', 6),
  serviceLogs: seq('sl', 4),
  schedule: seq('sc', 4),
  engineers: ['eng-u2', 'eng-e10', 'eng-e11', 'eng-e12'],
  tasks: seq('tsk', 5),
  stockMoves: seq('sm', 8),
  deliveries: seq('do', 3),
  expenses: seq('ex', 6),
  notifications: seq('n', 6),
  catalogAssets: seq('ca', 2),
};

function purgeLegacyDemoRecords(stored: Partial<AppState>): AppState {
  const base = { ...buildSeed(), ...stored } as AppState;
  const rec = base as unknown as Record<string, unknown>;
  for (const [key, ids] of Object.entries(LEGACY_DEMO_IDS)) {
    const arr = rec[key];
    if (Array.isArray(arr)) {
      rec[key] = arr.filter(
        (r) => !(r && typeof r === 'object' && 'id' in r && ids.includes((r as { id: string }).id)),
      );
    }
  }
  return base;
}

// Server returns users without the password field; the app User type requires it.
function toAppUser(u: unknown): User {
  return { ...(u as object), password: '' } as User;
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [state, setState] = useState<AppState>(buildSeed);

  // Authoritative, synchronously-updated copy of state so mutators can compute
  // the next value and fire server writes without stale closures.
  const stateRef = useRef<AppState>(state);

  // Server data hooks (core entities).
  const usersQ = useGetUsers();
  const ticketsQ = useGetTickets();
  const scheduleQ = useGetSchedule();
  const engineersQ = useGetEngineers();
  const settingsQ = useGetSettings();

  // Mutation hooks (fire-and-forget writes; local state is optimistic).
  const loginM = useLogin();
  const createUserM = useCreateUser();
  const updateUserM = useUpdateUser();
  const createTicketM = useCreateTicket();
  const updateTicketM = useUpdateTicket();
  const createScheduleM = useCreateScheduleEntry();
  const updateScheduleM = useUpdateScheduleEntry();
  const updateEngineerM = useUpdateEngineer();
  const updateSettingsM = useUpdateSettings();

  const applyState = useCallback((next: AppState) => {
    stateRef.current = next;
    setState(next);
  }, []);

  const persist = useCallback(async (next: AppState) => {
    try {
      await AsyncStorage.setItem(`${STORAGE_KEY}_data`, JSON.stringify(next));
    } catch { /* silently fail */ }
  }, []);

  // Apply an updater synchronously, persist, and return the next state so the
  // caller can fire the corresponding server mutation with fresh data.
  const update = useCallback((updater: (prev: AppState) => AppState): AppState => {
    const next = updater(stateRef.current);
    applyState(next);
    persist(next);
    return next;
  }, [applyState, persist]);

  // ---- Initial load: AsyncStorage cache (fast, offline-friendly). ----
  useEffect(() => {
    let active = true;
    async function init() {
      try {
        const [storedUser, storedData, storedVersion] = await Promise.all([
          AsyncStorage.getItem(`${STORAGE_KEY}_user`),
          AsyncStorage.getItem(`${STORAGE_KEY}_data`),
          AsyncStorage.getItem(`${STORAGE_KEY}_version`),
        ]);
        if (!active) return;
        if (storedUser) setCurrentUser(JSON.parse(storedUser));
        if (storedData) {
          const parsed = JSON.parse(storedData) as Partial<AppState>;
          const version = storedVersion ? parseInt(storedVersion, 10) || 0 : 0;
          if (version < SEED_VERSION) {
            // Returning device on an older seed version: strip legacy demo/sample
            // records by their fixed seed ids while preserving any user-created
            // data. The server remains authoritative for core entities and will
            // merge its data in once its queries resolve.
            const cleaned = purgeLegacyDemoRecords(parsed);
            applyState(cleaned);
            await AsyncStorage.multiSet([
              [`${STORAGE_KEY}_data`, JSON.stringify(cleaned)],
              [`${STORAGE_KEY}_version`, String(SEED_VERSION)],
            ]);
          } else {
            applyState({ ...buildSeed(), ...parsed });
          }
        } else {
          const seed = buildSeed();
          applyState(seed);
          await AsyncStorage.multiSet([
            [`${STORAGE_KEY}_data`, JSON.stringify(seed)],
            [`${STORAGE_KEY}_version`, String(SEED_VERSION)],
          ]);
        }
      } catch {
        if (active) applyState(buildSeed());
      } finally {
        if (active) setIsLoading(false);
      }
    }
    init();
    return () => { active = false; };
  }, [applyState]);

  // ---- Server is authoritative for core entities: merge on arrival. ----
  useEffect(() => {
    if (!usersQ.data) return;
    const next = { ...stateRef.current, users: (usersQ.data as unknown[]).map(toAppUser) };
    applyState(next);
    persist(next);
  }, [usersQ.data, applyState, persist]);

  useEffect(() => {
    if (!ticketsQ.data) return;
    const next = { ...stateRef.current, tickets: ticketsQ.data as unknown as ServiceTicket[] };
    applyState(next);
    persist(next);
  }, [ticketsQ.data, applyState, persist]);

  useEffect(() => {
    if (!scheduleQ.data) return;
    const next = { ...stateRef.current, schedule: scheduleQ.data as unknown as ScheduleEntry[] };
    applyState(next);
    persist(next);
  }, [scheduleQ.data, applyState, persist]);

  useEffect(() => {
    if (!engineersQ.data) return;
    const next = { ...stateRef.current, engineers: engineersQ.data as unknown as EngineerProfile[] };
    applyState(next);
    persist(next);
  }, [engineersQ.data, applyState, persist]);

  useEffect(() => {
    if (!settingsQ.data) return;
    const s = settingsQ.data;
    const next: AppState = {
      ...stateRef.current,
      company: s.company as unknown as CompanySettings,
      branding: s.branding as unknown as BrandingSettings,
      integrations: s.integrations as unknown as IntegrationSettings,
      notificationSettings: s.notificationSettings as unknown as NotificationSettings,
    };
    applyState(next);
    persist(next);
  }, [settingsQ.data, applyState, persist]);

  const setUser = useCallback((u: User | null) => {
    setCurrentUser(u);
    if (u) {
      AsyncStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(u)).catch(() => {});
    } else {
      AsyncStorage.removeItem(`${STORAGE_KEY}_user`).catch(() => {});
    }
  }, []);

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    try {
      const u = await loginM.mutateAsync({ data: { email, password } });
      setUser(toAppUser(u));
      return true;
    } catch (e) {
      const status = (e as { status?: number })?.status;
      if (status === 401) return false;
      // Network/server unavailable: fall back to offline seed authentication.
      const seedUser = ALL_USERS.find(
        u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );
      if (seedUser && seedUser.isActive !== false) {
        setUser({ ...seedUser, password: '' });
        return true;
      }
      return false;
    }
  }, [loginM, setUser]);

  const logout = useCallback(() => {
    setUser(null);
  }, [setUser]);

  const pushLog = useCallback((prev: AppState, ticket: ServiceTicket, action: string, fromStatus?: string, toStatus?: string, note?: string): ServiceLog[] => {
    const log: ServiceLog = {
      id: makeId(),
      ticketId: ticket.id,
      ticketNo: ticket.ticketNo,
      userId: currentUser?.id ?? 'u2',
      userName: currentUser?.name ?? ticket.assignedEngineerName,
      action,
      fromStatus,
      toStatus,
      note,
      createdAt: now(),
    };
    return [log, ...prev.serviceLogs];
  }, [currentUser]);

  // Fire a server PATCH for a single ticket using its latest local snapshot.
  const syncTicket = useCallback((next: AppState, id: string) => {
    const t = next.tickets.find(x => x.id === id);
    if (t) updateTicketM.mutate({ id, data: t as unknown as ServiceTicketUpdate });
  }, [updateTicketM]);

  const addTicket = useCallback((ticket: Omit<ServiceTicket, 'id' | 'ticketNo' | 'createdAt'>) => {
    const id = makeId();
    const next = update(prev => {
      const seq = prev.tickets.length + 1;
      const newTicket: ServiceTicket = {
        ...ticket,
        id,
        ticketNo: `CJ-TK-2024-${padNum(90 + seq)}`,
        createdAt: today(),
        photos: ticket.photos ?? [],
        usedParts: ticket.usedParts ?? [],
      };
      const notif: Notification = {
        id: makeId(), userId: newTicket.assignedEngineerId,
        title: 'New Job Assigned', message: `${newTicket.ticketNo} - ${newTicket.customerName}: ${newTicket.title}`,
        type: 'job_assigned', isRead: false, createdAt: now(),
      };
      return {
        ...prev,
        tickets: [newTicket, ...prev.tickets],
        serviceLogs: pushLog(prev, newTicket, 'Ticket created', undefined, newTicket.status),
        notifications: [notif, ...prev.notifications],
      };
    });
    const created = next.tickets.find(x => x.id === id);
    if (created) createTicketM.mutate({ data: created as unknown as ServiceTicketInput });
  }, [update, pushLog, createTicketM]);

  const updateTicketStatus = useCallback((id: string, status: TicketStatus, note?: string) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === id);
      if (!t) return prev;
      return {
        ...prev,
        tickets: prev.tickets.map(x =>
          x.id === id
            ? { ...x, status, workNotes: note ?? x.workNotes, completedDate: status === 'completed' ? today() : x.completedDate }
            : x
        ),
        serviceLogs: pushLog(prev, t, `Status changed to ${status}`, t.status, status, note),
      };
    });
    syncTicket(next, id);
  }, [update, pushLog, syncTicket]);

  const assignEngineer = useCallback((ticketId: string, engineerId: string, engineerName: string) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      const notif: Notification = {
        id: makeId(), userId: engineerId,
        title: 'Job Assigned', message: `${t.ticketNo} - ${t.customerName} assigned to you.`,
        type: 'job_assigned', isRead: false, createdAt: now(),
      };
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, assignedEngineerId: engineerId, assignedEngineerName: engineerName, status: x.status === 'pending' ? 'assigned' : x.status } : x),
        serviceLogs: pushLog(prev, t, `Assigned to ${engineerName}`, t.status, 'assigned'),
        notifications: [notif, ...prev.notifications],
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const startTravel = useCallback((ticketId: string) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, status: 'on_the_way', travelStartAt: now() } : x),
        serviceLogs: pushLog(prev, t, 'Started travel to site', t.status, 'on_the_way'),
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const startWork = useCallback((ticketId: string) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      const totalTravelMs = t.travelStartAt ? (Date.now() - new Date(t.travelStartAt).getTime()) : t.totalTravelMs;
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, status: 'in_progress', workStartAt: now(), isPaused: false, pausedMs: 0, totalTravelMs } : x),
        serviceLogs: pushLog(prev, t, 'Started work', t.status, 'in_progress'),
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const pauseWork = useCallback((ticketId: string) => {
    const next = update(prev => ({
      ...prev,
      tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, isPaused: true, pauseStartedAt: now() } : x),
    }));
    syncTicket(next, ticketId);
  }, [update, syncTicket]);

  const resumeWork = useCallback((ticketId: string) => {
    const next = update(prev => ({
      ...prev,
      tickets: prev.tickets.map(x => {
        if (x.id !== ticketId) return x;
        const extra = x.pauseStartedAt ? (Date.now() - new Date(x.pauseStartedAt).getTime()) : 0;
        return { ...x, isPaused: false, pauseStartedAt: undefined, pausedMs: (x.pausedMs ?? 0) + extra };
      }),
    }));
    syncTicket(next, ticketId);
  }, [update, syncTicket]);

  const completeWork = useCallback((ticketId: string) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      const totalWorkMs = t.workStartAt ? (Date.now() - new Date(t.workStartAt).getTime() - (t.pausedMs ?? 0)) : t.totalWorkMs;
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, workEndAt: now(), totalWorkMs, isPaused: false } : x),
        serviceLogs: pushLog(prev, t, 'Work completed (timer stopped)'),
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const addTicketPart = useCallback((ticketId: string, part: ServicePart) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      const move: StockMove = {
        id: makeId(), productId: part.productId, productName: part.productName, qty: part.qty,
        moveType: 'service_use', moveDate: today(), createdBy: currentUser?.id ?? 'u2',
        reference: t.ticketNo, notes: `Used in service - ${t.customerName}`,
      };
      const products = prev.products.map(p => p.id === part.productId ? { ...p, currentStock: Math.max(0, p.currentStock - part.qty) } : p);
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, usedParts: [...(x.usedParts ?? []), part] } : x),
        stockMoves: [move, ...prev.stockMoves],
        products,
        serviceLogs: pushLog(prev, t, `Added part: ${part.productName} x${part.qty} (${part.billing ?? 'free'})`),
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, currentUser, syncTicket]);

  const addTicketPhoto = useCallback((ticketId: string, photo: Omit<ServicePhoto, 'id' | 'createdAt'>) => {
    const next = update(prev => ({
      ...prev,
      tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, photos: [...(x.photos ?? []), { ...photo, id: makeId(), createdAt: now() }] } : x),
    }));
    syncTicket(next, ticketId);
  }, [update, syncTicket]);

  const saveSignature = useCallback((ticketId: string, sig: Omit<ServiceSignature, 'signedAt'>) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? { ...x, signature: { ...sig, signedAt: now() } } : x),
        serviceLogs: pushLog(prev, t, 'Customer signature captured'),
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const submitReport = useCallback((ticketId: string, report: Omit<ServiceReport, 'submittedAt'>) => {
    const next = update(prev => {
      const t = prev.tickets.find(x => x.id === ticketId);
      if (!t) return prev;
      const newStatus: TicketStatus = report.revisitRequired ? 'revisit' : 'completed';
      const notif: Notification = {
        id: makeId(), userId: 'u1',
        title: 'Service Report Submitted', message: `${t.ticketNo} - ${t.customerName} marked ${newStatus}.`,
        type: 'status_change', isRead: false, createdAt: now(),
      };
      return {
        ...prev,
        tickets: prev.tickets.map(x => x.id === ticketId ? {
          ...x,
          report: { ...report, submittedAt: now() },
          status: newStatus,
          revisitRequired: report.revisitRequired,
          completedDate: newStatus === 'completed' ? today() : x.completedDate,
        } : x),
        serviceLogs: pushLog(prev, t, 'Final report submitted', t.status, newStatus),
        notifications: [notif, ...prev.notifications],
      };
    });
    syncTicket(next, ticketId);
  }, [update, pushLog, syncTicket]);

  const addScheduleEntry = useCallback((entry: Omit<ScheduleEntry, 'id'>) => {
    const id = makeId();
    const next = update(prev => ({ ...prev, schedule: [{ ...entry, id }, ...prev.schedule] }));
    const created = next.schedule.find(s => s.id === id);
    if (created) createScheduleM.mutate({ data: created as unknown as ScheduleEntryInput });
  }, [update, createScheduleM]);

  const updateScheduleStatus = useCallback((id: string, status: ScheduleEntry['status']) => {
    update(prev => ({ ...prev, schedule: prev.schedule.map(s => s.id === id ? { ...s, status } : s) }));
    updateScheduleM.mutate({ id, data: { status } as unknown as ScheduleEntryUpdate });
  }, [update, updateScheduleM]);

  const updateEngineer = useCallback((id: string, data: Partial<EngineerProfile>) => {
    const next = update(prev => ({ ...prev, engineers: prev.engineers.map(e => e.id === id ? { ...e, ...data } : e) }));
    const eng = next.engineers.find(e => e.id === id);
    if (eng) updateEngineerM.mutate({ id, data: eng as unknown as EngineerProfileUpdate });
  }, [update, updateEngineerM]);

  const addUser = useCallback((user: Omit<User, 'id'>) => {
    const id = makeId();
    const next = update(prev => ({ ...prev, users: [{ ...user, id }, ...prev.users] }));
    const created = next.users.find(u => u.id === id);
    if (created) createUserM.mutate({ data: created as unknown as UserInput });
  }, [update, createUserM]);

  const updateUser = useCallback((id: string, data: Partial<User>) => {
    update(prev => ({ ...prev, users: prev.users.map(u => u.id === id ? { ...u, ...data } : u) }));
    updateUserM.mutate({ id, data: data as unknown as UserUpdate });
  }, [update, updateUserM]);

  const toggleUserActive = useCallback((id: string) => {
    const next = update(prev => ({ ...prev, users: prev.users.map(u => u.id === id ? { ...u, isActive: !u.isActive } : u) }));
    const u = next.users.find(x => x.id === id);
    if (u) updateUserM.mutate({ id, data: { isActive: u.isActive } as unknown as UserUpdate });
  }, [update, updateUserM]);

  const addCategory = useCallback((name: string, icon?: string) => {
    update(prev => ({ ...prev, categories: [...prev.categories, { id: makeId(), name, icon }] }));
  }, [update]);

  const deleteCategory = useCallback((id: string) => {
    update(prev => ({ ...prev, categories: prev.categories.filter(c => c.id !== id) }));
  }, [update]);

  const addCatalogAsset = useCallback((asset: Omit<CatalogAsset, 'id' | 'createdAt'>) => {
    update(prev => ({ ...prev, catalogAssets: [{ ...asset, id: makeId(), createdAt: today() }, ...prev.catalogAssets] }));
  }, [update]);

  const deleteCatalogAsset = useCallback((id: string) => {
    update(prev => ({ ...prev, catalogAssets: prev.catalogAssets.filter(a => a.id !== id) }));
  }, [update]);

  const saveCompany = useCallback((data: Partial<CompanySettings>) => {
    const next = update(prev => ({ ...prev, company: { ...prev.company, ...data } }));
    updateSettingsM.mutate({ data: { company: next.company } as unknown as SettingsUpdate });
  }, [update, updateSettingsM]);

  const saveBranding = useCallback((data: Partial<BrandingSettings>) => {
    const next = update(prev => ({ ...prev, branding: { ...prev.branding, ...data } }));
    updateSettingsM.mutate({ data: { branding: next.branding } as unknown as SettingsUpdate });
  }, [update, updateSettingsM]);

  const saveIntegrations = useCallback((data: IntegrationSettings) => {
    update(prev => ({ ...prev, integrations: data }));
    updateSettingsM.mutate({ data: { integrations: data } as unknown as SettingsUpdate });
  }, [update, updateSettingsM]);

  const saveNotificationSettings = useCallback((data: NotificationSettings) => {
    update(prev => ({ ...prev, notificationSettings: data }));
    updateSettingsM.mutate({ data: { notificationSettings: data } as unknown as SettingsUpdate });
  }, [update, updateSettingsM]);

  const addInvoice = useCallback((invoice: Omit<Invoice, 'id' | 'invoiceNo'>) => {
    update(prev => {
      const seq = prev.invoices.length + 1;
      const newInvoice: Invoice = { ...invoice, id: makeId(), invoiceNo: `CJ-INV-2024-${padNum(143 + seq)}` };
      return { ...prev, invoices: [newInvoice, ...prev.invoices] };
    });
  }, [update]);

  const addPayment = useCallback((payment: Omit<Payment, 'id' | 'paymentNo'>) => {
    update(prev => {
      const seq = prev.payments.length + 1;
      const newPayment: Payment = { ...payment, id: makeId(), paymentNo: `CJ-PAY-2024-${padNum(89 + seq)}` };
      const updatedInvoices = payment.invoiceId
        ? prev.invoices.map(inv => {
            if (inv.id !== payment.invoiceId) return inv;
            const newPaid = inv.totalPaid + payment.amount;
            const newDue = Math.max(0, inv.totalAmount - newPaid);
            return { ...inv, totalPaid: newPaid, totalDue: newDue, status: newDue === 0 ? 'paid' as const : 'partial' as const };
          })
        : prev.invoices;
      return { ...prev, payments: [newPayment, ...prev.payments], invoices: updatedInvoices };
    });
  }, [update]);

  const addExpense = useCallback((expense: Omit<Expense, 'id' | 'createdAt'>) => {
    update(prev => {
      const newExpense: Expense = { ...expense, id: makeId(), createdAt: today() };
      return { ...prev, expenses: [newExpense, ...prev.expenses] };
    });
  }, [update]);

  const addStockMove = useCallback((move: Omit<StockMove, 'id'>) => {
    update(prev => {
      const newMove: StockMove = { ...move, id: makeId() };
      const updatedProducts = prev.products.map(p => {
        if (p.id !== move.productId) return p;
        const delta = move.moveType === 'purchase_in' ? move.qty : -move.qty;
        return { ...p, currentStock: Math.max(0, p.currentStock + delta) };
      });
      return { ...prev, stockMoves: [newMove, ...prev.stockMoves], products: updatedProducts };
    });
  }, [update]);

  const updateDeliveryStatus = useCallback((id: string, status: DeliveryOrder['status']) => {
    update(prev => ({ ...prev, deliveries: prev.deliveries.map(d => d.id === id ? { ...d, status } : d) }));
  }, [update]);

  const updateTaskStatus = useCallback((id: string, status: MarketingTask['status'], data?: Partial<MarketingTask>) => {
    update(prev => ({ ...prev, tasks: prev.tasks.map(t => t.id === id ? { ...t, status, ...data } : t) }));
  }, [update]);

  const markNotificationRead = useCallback((id: string) => {
    update(prev => ({ ...prev, notifications: prev.notifications.map(n => n.id === id ? { ...n, isRead: true } : n) }));
  }, [update]);

  const markAllNotificationsRead = useCallback(() => {
    update(prev => ({ ...prev, notifications: prev.notifications.map(n => ({ ...n, isRead: true })) }));
  }, [update]);

  const unreadCount = state.notifications.filter(n => !n.isRead && (n.userId === currentUser?.id || n.userId === 'u1')).length;

  return (
    <AppContext.Provider value={{
      ...state,
      currentUser,
      isLoading,
      login,
      logout,
      addTicket,
      updateTicketStatus,
      assignEngineer,
      startTravel,
      startWork,
      pauseWork,
      resumeWork,
      completeWork,
      addTicketPart,
      addTicketPhoto,
      saveSignature,
      submitReport,
      addScheduleEntry,
      updateScheduleStatus,
      updateEngineer,
      addUser,
      updateUser,
      toggleUserActive,
      addCategory,
      deleteCategory,
      addCatalogAsset,
      deleteCatalogAsset,
      saveCompany,
      saveBranding,
      saveIntegrations,
      saveNotificationSettings,
      addInvoice,
      addPayment,
      addExpense,
      addStockMove,
      updateDeliveryStatus,
      updateTaskStatus,
      markNotificationRead,
      markAllNotificationsRead,
      unreadCount,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
